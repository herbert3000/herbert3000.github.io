
Installation:
Extract WARGAME.DIR and then delete the file.
Copy the files from the folder INST in this directory to your Commandos installation directory.


This mission is still in development.
Please send any suggestions to: ferdinand.graf.zeppelin@gmail.com
Thank you!

