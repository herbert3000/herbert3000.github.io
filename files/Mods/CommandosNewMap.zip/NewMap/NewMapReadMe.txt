 A new map for Commandos: Behind Enemy Lines
  (based on sprites from the first mission)
=============================================

Make sure WARGAME.DIR has been extracted and deleted (or renamed).

Where you have to store the files:
MAPA0000.MIS->DATOS\MISIONES (backup the original MAPA0000.MIS!)
MAPA1000.SEC->DATOS\MISIONES
MAPA1000.VOL->DATOS\MISIONES
CHOQ1000.VOL->DATOS\MISIONES
FASE1000.WAD->DATOS\RECURSOS\BMPS\MAP
LIBR1000.RLE->DATOS\RECURSOS\BMPS\SYSTEM\LIBRETAS


Mission objective: Destroy the truck. (The hardest mission ever!)

Feel free to add enemies, vehicles, barrels, etc. to the map.

Things you can't do:
- you cant't climb the wall
- you cant't use the MG
- you cant't destroy buildings
Why? -Because it's much easier creating a map without adding hundreds of tiles.

Please contact me, if you have any problems with the map.



No warranty, all rights reserved.
� 2009 Ferdinand.Graf.Zeppelin@gmail.com
       sites.google.com/site/commandosmod
"Commandos: Behind Enemy Lines" is a trademark of Eidos Interactive Ltd