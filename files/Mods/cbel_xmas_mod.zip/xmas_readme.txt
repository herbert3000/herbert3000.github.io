Commandos BEL Christmas Mod
===========================

Don't expect too much,
I took me less than two hours to make this mod.

Install info:
- extract "WARGAME.DIR" and delete (or rename) it
- move "CHOQ0000.VOL" and "MAPA0000.VOL" to the folder "DATOS\MISIONES"
- move "FASE0000.WAD" to the folder "DATOS\RECURSOS\BMPS\MAP"
  (don't forget to make a backup of the original files)
- start Commandos and have fun


   ***************************
   **    Merry Christmas!   **
   ** And a happy new year! **
   ***************************




Contact:
ferdinand.graf.zeppelin@gmail.com
sites.google.com/site/commandosmod

23-12-09 05:13