Here's the actual Resolution Fix:
http://modelrail.otenko.com/electronics/commandos-behind-enemy-lines-resolution-fix


However if your screen resolution is higher than the dimension of a map, you'll have to fix the *.VOL file of that map.
This is how you do it:
Open the *.VOL file (with notepad or any other text editor) and check if the values after the keyword MAPDIMXY are smaller than the resolution.
If that's the case, insert a new POLY block like this (see MAPA0021.VOL as an example):

POLY "WIDESCREENFIX",0,0,0,0,0,2
	RADIO		0
	TILE        1040,   0, 880,1080,   0,   0,-20,"CESPED.BMP","   "
	TILE           0, 950,1040, 130,   0,   0,-20,"CESPED.BMP","   "

Have a look at 'vol_fix.png' for more information about how to get the correct values.
Also choose the right BMP according to this list:

MAPA0000.VOL	CESPED.BMP
MAPA0001.VOL	CESPED1.BMP
MAPA0002.VOL	CESPED.BMP
MAPA0003.VOL	CESPED.BMP
MAPA0004.VOL	DESIERTO.BMP
MAPA0005.VOL	MAR0DST.BMP
MAPA0006.VOL	NIEVE6.BMP
MAPA0007.VOL	SUEL01.BMP
MAPA0008.VOL	DESIERTO.BMP
MAPA0009.VOL	DESIERTO.BMP
MAPA0010.VOL	TERR00.BMP
MAPA0012.VOL	TERR00.BMP
MAPA0013.VOL	TEJAD001.BMP
MAPA0015.VOL	DESIERTO.BMP
MAPA0016.VOL	TERRENO.BMP
MAPA0017.VOL	TERRENO.BMP
MAPA0018.VOL	SU1809.BMP
MAPA0019.VOL	MAR0DST.BMP
MAPA0020.VOL	VERDE.BMP
MAPA0021.VOL	CESPED.BMP
MAPA0022.VOL	CESPED.BMP
MAPA0023.VOL	CESPED.BMP
MAPA0024.VOL	CESPED.BMP

How does it work? - The fix adds two big grass tiles (CESPED.BMP) to the map, one on the right side of the original map, one at the bottom. The '-20' adjusts the brightness of the tile, -20 is the minimum value so the tile appears completely black.


If you only have to fix one side of the map, insert this kind of POLY block instead:

POLY "WIDESCREENFIX",0,0,0,0,0,1
	RADIO		0
	TILE        1040,   0, 880,1040,   0,   0,-20,"CESPED.BMP","   "


Have fun!
---
ferdinand.graf.zeppelin@gmail.com
