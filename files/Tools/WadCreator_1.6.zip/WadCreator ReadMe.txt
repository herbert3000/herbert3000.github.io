 Commandos - WAD Creator
-------------------------

This program repacks (or creates) extracted "Commandos Behind Enemy Lines" *.WAD archives.

Usage: WadCreator <InputFolder>
=
  Drag & Drop a folder onto the WadCreator.exe
-or-
  Run WadCreator.exe and type in the name of the folder

To extract a WAD archive, use the MultiExtractor.

All types of bitmaps are supported now!
You can add 1, 4, 8 and even 24-bit bmp's.
Source image and mask don't need to have the same color depth.
A default color palette (similiar to the MS Paint palette) for all 24-bit bmp's will be created = big loss of quality.
It's highly recommended to create an optimized palette for each true color bitmap!

To add IMAGE01.RLE to the archive, you have to store
 - IMAGE01.BMP
 - IMAGE01.MASK.BMP
in the <InputFolder>. No *.RLE extensions allowed!

If the <InputFolder> is called EXAMPLE,
the file EXAMPLE.WAD will be created.

If the <InputFolder> is called EXAMPLE.WAD.FILES,
the file EXAMPLE.WAD will be created as well.

MASK colors:
Black(RGB:0,0,0) = transparent,
White(RGB:255,255,255) = opaque,
anything else = semi-transparent

Don't forget to backup the original files before you replace them.

Please contact me, if the program reports any error message
or when the game crashes with the new WAD archive.

No warranty, all rights reserved.
� 2011 ferdinand.graf.zeppelin@gmail.com aka herbert3000
http://sites.google.com/site/commandosmod/
Commandos Behind Enemy Lines is a trademark of Pyro Studios S.L.


v1.6/110727