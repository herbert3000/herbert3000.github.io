package com.commandos.abiconverter.fileIO;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.List;

import com.commandos.abiconverter.entities.AbiFile;
import com.commandos.abiconverter.entities.Animation;
import com.commandos.abiconverter.entities.Bone;
import com.commandos.abiconverter.entities.BoneAnimation;
import com.commandos.abiconverter.entities.BoneIndex;
import com.commandos.abiconverter.entities.Border;
import com.commandos.abiconverter.entities.Model;
import com.commandos.abiconverter.entities.Polygon;
import com.commandos.abiconverter.entities.RotKeyframe;
import com.commandos.abiconverter.entities.Texture;
import com.commandos.abiconverter.entities.TimeAxis;
import com.commandos.abiconverter.entities.TransKeyframe;
import com.commandos.abiconverter.entities.Vertex;
import com.commandos.abiconverter.utils.Constants;
import com.commandos.abiconverter.utils.FileSystem;
import com.commandos.abiconverter.xml.IXmlWriter;
import com.commandos.abiconverter.xml.SimpleXmlWriter;

public class XmlWriter {

	public static void writeXml(AbiFile abi, int version, String filename) throws IOException {
		String foldername = filename + Constants.FOLDER_EXTENSION;
		FileSystem.createFolder(foldername);
		
		FileOutputStream fos = new FileOutputStream(foldername + "\\Debug.xml");
		BufferedOutputStream bos = new BufferedOutputStream(fos);
		OutputStreamWriter out = new OutputStreamWriter(bos, "UTF-8");
		switch (version) {
			case 1011:
			case 1040:
			case 1050:
			case 1060:
				writeXml1060(abi, version, out);
				break;
			default:
				break;
		}
		out.close();
	}

	private static void writeXml1060(AbiFile abi, int version, OutputStreamWriter xml) throws IOException {
		IXmlWriter xmlWriter = new SimpleXmlWriter(xml);
		
		xmlWriter.createNode("LDMB");
		xmlWriter.createNode("Version", version);
		
		xmlWriter.createNode("Textures");
		for (Texture t : abi.getTextures()) {
			xmlWriter.createNode("Texture");
			xmlWriter.createNode("Name", t.getName());
			xmlWriter.createNode("TextureId",  t.getTextureId());
			xmlWriter.closeNode(); // Texture
		}
		xmlWriter.closeNode(); // Textures
		
		xmlWriter.createNode("Models");
		xmlWriter.createNode("ModelFlag", abi.getModelIdentifier());
		
		for (Model m : abi.getModels()) {
			xmlWriter.createNode("Model");
			xmlWriter.createNode("Name", m.getName());
			
			xmlWriter.createNode("Vertices");
			
			for (Vertex v : m.getVertices()) {
				xmlWriter.createNode("Vertex");
				xmlWriter.createNode("X", v.getX());
				xmlWriter.createNode("Y", v.getY());
				xmlWriter.createNode("Z", v.getZ());
				xmlWriter.closeNode(); // Vertex
			}
			xmlWriter.closeNode(); // Vertices
			
			xmlWriter.createNode("Polygons");
			
			for (Polygon p : m.getPolygons()) {
				xmlWriter.createNode("Polygon");
				xmlWriter.createNode("TextureIndex", p.getTextureId());
				xmlWriter.createNode("Vertices");
				
				for (Border b : p.getBorders()) {
					xmlWriter.createNode("VertexInfo");
					xmlWriter.createNode("VertexIndex", b.getId());
					xmlWriter.createNode("U", b.getU());
					xmlWriter.createNode("V", b.getV());
					xmlWriter.closeNode(); // VertexInfo
				}
				xmlWriter.closeNode(); // Vertices
				xmlWriter.closeNode(); // Polygon
			}
			xmlWriter.closeNode(); // Polygons
			
			xmlWriter.createNode("VerticesToBone");
			
			for (BoneIndex b : m.getRelatedBones()) {
				xmlWriter.createNode("VertexIndices");
				xmlWriter.createNode("StartVertexIndex", b.getStartIndex());
				xmlWriter.createNode("EndVertexIndex", b.getEndIndex());
				xmlWriter.closeNode(); // VertexIndices
			}
			xmlWriter.closeNode(); // VerticesToBone
			
			xmlWriter.closeNode(); // Model
		}
		xmlWriter.closeNode(); // Models
		
		xmlWriter.createNode("Bones");
		
		for (Bone b : abi.getBones()) {
			xmlWriter.createNode("Bone");
			xmlWriter.createNode("ParentIndex", b.getParent());
			xmlWriter.createNode("TransformationMatrix");
			xmlWriter.createNode("X", b.getTransformX());
			xmlWriter.createNode("Y", b.getTransformY());
			xmlWriter.createNode("Z", b.getTransformZ());
			xmlWriter.closeNode(); // TransformationMatrix
			xmlWriter.createNode("Name", b.getName());
			xmlWriter.createNode("BoneUnknown", b.getUnknown());
			xmlWriter.closeNode(); // Bone
		}
		xmlWriter.closeNode(); // Bones
		
		xmlWriter.createNode("TransformationTimeAxes");
		
		for (TimeAxis t : abi.getTimeAxes()) {
			xmlWriter.createNode("TransformationTimeAxis");
			
			xmlWriter.createNode("TranslationKeyframes");
			
			for (TransKeyframe tk : t.getTransKeyframes()) {
				xmlWriter.createNode("TranslationKeyframe");
				xmlWriter.createNode("Timestamp", tk.getTimestamp());
				xmlWriter.createNode("Dx", tk.getDx() / 256.0);
				xmlWriter.createNode("Dy", tk.getDy() / 256.0);
				xmlWriter.createNode("Dz", tk.getDz() / 256.0);
				xmlWriter.closeNode(); // TranslationKeyframe
			}
			xmlWriter.closeNode(); // TranslationKeyframes
			
			xmlWriter.createNode("RotationKeyframes");
			
			for (RotKeyframe rk : t.getRotKeyframes()) {
				xmlWriter.createNode("RotationKeyframe");
				xmlWriter.createNode("Timestamp", rk.getTimestamp());
					xmlWriter.createNode("X", rk.getX() / 32768.0);
					xmlWriter.createNode("Y", rk.getY() / 32768.0);
					xmlWriter.createNode("Z", rk.getZ() / 32768.0);
					xmlWriter.createNode("W", rk.getW() / 32768.0);
				xmlWriter.closeNode(); // RotationKeyframe
			}
			xmlWriter.closeNode(); // RotationKeyframes
			
			xmlWriter.closeNode(); // TransformationTimeAxis
		}
		xmlWriter.closeNode(); // TransformationTimeAxes
		
		xmlWriter.createNode("Animations");
		
		for (Animation a : abi.getAnimations()) {
			List<BoneAnimation> boneAnims = a.getBoneAnimations();
			xmlWriter.createNode("Animation");
			xmlWriter.createNode("Name", a.getName());
			xmlWriter.createNode("BoneAnimationEntries");
			for (int j = 0; j < a.getNumRelatedBones(); j++) {
				xmlWriter.createNode("BoneAnimationEntry");
				xmlWriter.createNode("BoneIndex", boneAnims.get(j).getBoneId());
				xmlWriter.createNode("TimeAxisIndex", boneAnims.get(j).getTimeaxisId());
				xmlWriter.closeNode(); // BoneAnimationEntry
			}
			xmlWriter.closeNode(); // BoneAnimationEntries
			xmlWriter.closeNode(); // Animation
		}
		xmlWriter.closeNode(); // Animations
		
		xmlWriter.closeNode(); // LDMB
		
		xmlWriter.close();
	}
}
