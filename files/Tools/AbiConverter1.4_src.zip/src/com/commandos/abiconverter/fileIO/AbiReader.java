package com.commandos.abiconverter.fileIO;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.commandos.abiconverter.entities.AbiFile;
import com.commandos.abiconverter.entities.Animation;
import com.commandos.abiconverter.entities.Bone;
import com.commandos.abiconverter.entities.BoneAnimation;
import com.commandos.abiconverter.entities.BoneIndex;
import com.commandos.abiconverter.entities.Border;
import com.commandos.abiconverter.entities.Model;
import com.commandos.abiconverter.entities.Polygon;
import com.commandos.abiconverter.entities.RotKeyframe;
import com.commandos.abiconverter.entities.Texture;
import com.commandos.abiconverter.entities.TimeAxis;
import com.commandos.abiconverter.entities.TransKeyframe;
import com.commandos.abiconverter.entities.Vertex;
import com.commandos.abiconverter.utils.Constants;
import com.commandos.abiconverter.utils.FileSystem;

public class AbiReader {

	public void extractBitmaps(AbiFile abi, String filename) throws IOException {
		String foldername = filename + Constants.FOLDER_EXTENSION;
		FileSystem.createFolder(foldername);
		foldername += "\\Textures";
		FileSystem.createFolder(foldername);
		
		for (Texture t : abi.getTextures()) {
			t.extractBitmap(foldername);
		}
	}

	public AbiFile readAbi(String filename, boolean polygonsToTriangles) throws IOException {
		LittleEndianDataInputStream file = new LittleEndianDataInputStream(filename);
		
		// LDMB Header
		file.skipBytes(4);
		String ver = file.readIdent();
		file.close();
		
		int version = Integer.parseInt(ver);
		
		if (version == 1011) {
			return readAbi3(filename, polygonsToTriangles);
		}
		
		return readAbi2(filename, polygonsToTriangles);
	}

	public AbiFile readAbi3(String filename, boolean polygonsToTriangles) throws IOException {
		LittleEndianRandomAccessFile file = new LittleEndianRandomAccessFile(filename, "r");
		
		// LDMB Header
		file.seek(8);
		file.readShort2(); // unknown
		
		byte modelIdentifier = 0;
		
		int numTimeaxes  = file.readShort2();
		int numAnimations = file.readShort2();
		int numTextures   = file.readShort2();
		int numModels     = file.readShort2();
		int numBones      = file.readShort2();
		
		int offsetTexture  = file.readInt2();
		int offsetModel    = file.readInt2();
		
		file.skipBytes(12);
		/*
		int offsetAnimationHeader = file.readInt2();
		int sizeBoneTrans = file.readInt2();
		int sizeTimeaxis   = file.readInt2();
		*/
		
		List<Texture> textures = new ArrayList<Texture>();
		
		for (int i = 0; i < numTextures; i++) {
			int width = file.readShort2();
			int height = file.readShort2();
			int widthXheight = width*height;
			byte pal[] = new byte[256*3];
			byte pix[] = new byte[widthXheight];
			file.read(pal);
			String name = file.readString(32);
			if (name.length() == 0) {
				name = "Untitled-" + i + ".bmp";
			} else {
				String n = (name.substring(name.length()-4, name.length())).toLowerCase();
				if (!n.equals(".bmp")) {
					name += ".bmp";
				}
			}
			name = name.replace(" ", "_");
			
			int textureId = file.readInt2();
			int offset = file.readInt2();
			int relativeTextureOffset = offset - offsetTexture;
			
			long pos = file.getFilePointer();
			file.seek(offset);
			file.read(pix);
			file.seek(pos);
			
			textures.add(new Texture(width, height, name, pal, pix, relativeTextureOffset, textureId));
		}
		
		List<Bone> bones = new ArrayList<Bone>();
		for (int i = 0; i < numBones; i++) {
			int parent = file.readInt2();
			int unknown = file.readInt2();
			float transformX = file.readFloat2();
			float transformY = file.readFloat2();
			float transformZ = file.readFloat2();
			String name = file.readString(32);
			
			bones.add(new Bone(parent, transformX, transformY, transformZ, name, unknown));
		}
		
		List<Model> models = new ArrayList<Model>();
		for (int i = 0; i < numModels; i++) {
			short numVertices      = file.readShort2();
			short numPolygons     = file.readShort2();
			/*short sumNumBorders =*/ file.readShort2();
			String name = file.readString(32);
			int offset = file.readInt2();
			int relativeModelOffset = offset - offsetModel;
			
			long pos = file.getFilePointer();
			file.seek(offset);
			
			List<Vertex> vertices = new ArrayList<Vertex>();
			for (int j = 0; j < numVertices; j++) {
				float x = file.readFloat2();
				float y = file.readFloat2();
				float z = file.readFloat2();
				
				vertices.add(new Vertex(x, y, z));
			}
			
			List<Polygon> polygons = new ArrayList<Polygon>();
			for (int j = 0; j < numPolygons; j++) {
				int numBorders = file.readUnsignedByte();
				short textureId = file.readShort2();
				
				List <Border> borders = new ArrayList<Border>();
				for (int k = 0; k < numBorders; k++) {
					int id  = file.readShort2();
					float u = (float) (file.readSignedShort() / 4096.0);
					float v = (float) (file.readSignedShort() / 4096.0);
					
					borders.add(new Border(id, u, v));
				}
				
				polygons.add(new Polygon(textureId, borders));
			}
			
			List<BoneIndex> relatedBones = new ArrayList<BoneIndex>();
			for (int j = 0; j < numBones; j++) {
				int startIndex = file.readInt2();
				int endIndex   = file.readInt2();
				
				relatedBones.add(new BoneIndex(startIndex, endIndex));
			}
			
			file.seek(pos);
			
			models.add(new Model(name, vertices, polygons, relatedBones, relativeModelOffset));
		}
		
		List<Animation> animations = new ArrayList<Animation>();
		for (int i = 0; i < numAnimations; i++) {
			String name = file.readString(32);
			int unknown = file.readInt2();
			file.skipBytes(16); // unknown, always 0
			
			animations.add(new Animation(name, unknown));
		}
		
		for (int i = 0; i < numAnimations; i++) {
			int numRelatedBones = file.readInt2();
			
			List<BoneAnimation> boneAnims = new ArrayList<BoneAnimation>();
			for (int j = 0; j < numRelatedBones; j++) {
				int boneId     = file.readInt2();
				int timeaxisId = file.readInt2();
				
				boneAnims.add(new BoneAnimation(boneId, timeaxisId));
			}
			
			animations.get(i).setBoneAnimation(boneAnims);
		}
		
		List<TimeAxis> timeAxes = new ArrayList<TimeAxis>();
		for (int i = 0; i < numTimeaxes; i++) {
			int numTranslateKeyframes = file.readUnsignedByte();
			int numRotateKeyframes = file.readUnsignedByte();
			
			List<TransKeyframe> transKeyframes = new ArrayList<TransKeyframe>();
			for (int j = 0; j < numTranslateKeyframes; j++) {
				short dx = file.readSignedShort();
				short dy = file.readSignedShort();
				short dz = file.readSignedShort();
				transKeyframes.add(new TransKeyframe(0, dx, dy, dz));
			}
			for (int j = 0; j < numTranslateKeyframes; j++) {
				int timestamp = file.readUnsignedByte();
				transKeyframes.get(j).setTimestamp(timestamp);
			}
			
			List<RotKeyframe> rotKeyframes = new ArrayList<RotKeyframe>();
			for (int j = 0; j < numRotateKeyframes; j++) {
				byte rx = file.readByte();
				byte ry = file.readByte();
				byte rz = file.readByte();
				rotKeyframes.add(new RotKeyframe(rx, ry, rz));
			}
			for (int j = 0; j < numRotateKeyframes; j++) {
				int timestamp = file.readUnsignedByte();
				rotKeyframes.get(j).setTimestamp(timestamp);
			}
			
			if (numTranslateKeyframes % 2 != 0) {
				file.skipBytes(1); // unknown, always 0x64
			}
			
			timeAxes.add(new TimeAxis(transKeyframes, rotKeyframes));
		}
		
		file.close();
		
		return new AbiFile(modelIdentifier, textures, bones, models, animations, timeAxes);
	}

	public AbiFile readAbi2(String filename, boolean polygonsToTriangles) throws IOException {
		LittleEndianDataInputStream file = new LittleEndianDataInputStream(filename);
		
		// ABI Header
		file.skipBytes(4);
		String ver = file.readIdent();
		int version = Integer.parseInt(ver);
		
		byte modelIdentifier = 0;
		
		int numTimeaxes  = file.readInt2();
		int numAnimations = file.readInt2();
		int numTextures   = file.readInt2();
		
		int sizeTexture = 0;
		int sizeModel = 0;
		
		// Textures
		List<Texture> textures = new ArrayList<>();
		
		for (int i = 0; i < numTextures; i++) {
			
			int identifier = file.readInt2();
			int width = file.readInt2();
			int height = file.readInt2();
			int widthXheight = width*height;
			String name = file.readString(32);
			if (name.length() == 0) {
				name = "Untitled-" + i + ".bmp";
			} else {
				String n = (name.substring(name.length()-4, name.length())).toLowerCase();
				if (!n.equals(".bmp")) {
					name += ".bmp";
				}
			}
			name = name.replace(" ", "_");
			
			byte pal[] = new byte[256*3];
			byte pix[] = new byte[widthXheight];
			file.read(pal);
			file.read(pix);
			
			int relativeTextureOffset = sizeTexture;
			textures.add(new Texture(identifier, width, height, name, pal, pix, relativeTextureOffset));
			
			sizeTexture += widthXheight;
		}
		
		// Model & Bone Header
		if (version == 1060) {
			modelIdentifier = file.readByte();
		}
		int numModels = file.readInt2();
		int numBones  = file.readInt2();
		
		// Models
		List<Model> models = new ArrayList<Model>();
		for (int i = 0; i < numModels; i++) {
			int numVertex  = file.readInt2();
			int numPolygon = file.readInt2();
			String name     = file.readString(32);
			//int sumNumBorders = 0;
			
			List<Vertex> vertices = new ArrayList<Vertex>();
			for (int j = 0; j < numVertex; j++) {
				float x = file.readFloat2();
				float y = file.readFloat2();
				float z = file.readFloat2();
				
				vertices.add(new Vertex(x, y, z));
			}
			
			//int numTriangles = 0;
			
			List<Polygon> polygons;
			List<Polygon> polygonsTemp = new ArrayList<Polygon>();
			
			for (int j = 0; j < numPolygon; j++) {
				int numBorders;
				int textureId;
				
				if (version == 1040) {
					numBorders = file.readInt2();
					textureId  = file.readInt2();
				} else { // version == 1050 || version == 1060
					numBorders = file.readUnsignedByte();
					textureId  = file.readUnsignedByte();
				}
				//sumNumBorders += numBorders;
				//numTriangles += numBorders - 2;
				
				List<Border> borders = new ArrayList<Border>();
				
				for (int k = 0; k < numBorders; k++) {
					int id;
					float u, v;
					if (version == 1040) {
						id = file.readInt2();
						u  = file.readFloat2();
						v  = file.readFloat2();
					} else { // version == 1050 || version == 1060
						id = file.readSignedShort();
						u  = (float) (file.readSignedShort() / 4096.0);
						v  = (float) (file.readSignedShort() / 4096.0);
					}
					borders.add(new Border(id, u, v));
				}
				
				polygonsTemp.add(new Polygon(textureId, borders));
			}
			
			if (!polygonsToTriangles) {
				
				polygons = polygonsTemp;
				
			} else {
				
				polygons = new ArrayList<>();
				
				for (Polygon p : polygonsTemp) {
					List<Border> b = p.getBorders();
					int numBorders = p.getNumBorders()-2;
					int textureId = p.getTextureId();
					
					for (int k = 0; k < numBorders; k++) {
						List <Border> borders = new ArrayList<Border>();
						
						
						borders.add(new Border(
							b.get(0).getId(),
							b.get(0).getU(),
							b.get(0).getV()));
							
						borders.add(new Border(
							b.get(k+1).getId(),
							b.get(k+1).getU(),
							b.get(k+1).getV()));
						
						borders.add(new Border(
							b.get(k+2).getId(),
							b.get(k+2).getU(),
							b.get(k+2).getV()));
						
						polygons.add(new Polygon(textureId, borders));
					}
				}
				
				//numPolygon = numTriangles;
				//sumNumBorders = numTriangles * 3;
			}
			
			List<BoneIndex> relatedBones = new ArrayList<BoneIndex>();
			for (int j = 0; j < numBones; j++) {
				int startIndex = file.readInt2();
				int endIndex   = file.readInt2();
				
				relatedBones.add(new BoneIndex(startIndex, endIndex));
			}
			
			int relativeModelOffset = sizeModel;
			models.add(new Model(name, vertices, polygons, relatedBones, relativeModelOffset));
			
			sizeModel += (numBones * 8) + models.get(i).length();
		}
		
		// Bones
		List<Bone> bones = new ArrayList<Bone>();
		for (int i = 0; i < numBones; i++) {
			int parent = file.readInt2();
			float transformX = file.readFloat2();
			float transformY = file.readFloat2();
			float transformZ = file.readFloat2();
			String name = file.readString(32);
			int unknown = file.readInt2();
			
			bones.add(new Bone(parent, transformX, transformY, transformZ, name, unknown));
		}
		
		// Time Axes
		List<TimeAxis> timeAxes = new ArrayList<TimeAxis>();
		
		if (version == 1040) {
			for (int i = 0; i < numTimeaxes; i++) {
				
				List<TransKeyframe> transKeyframes = new ArrayList<TransKeyframe>();
				List<RotKeyframe> rotKeyframes = new ArrayList<RotKeyframe>();
				
				int numFrames = file.readInt2();
				for (int j = 0; j < numFrames; j++) {
					int timestamp = (int) file.readFloat2();
					file.readInt2(); // unknown
					
					short dx = (short) (file.readFloat2() * 256);
					short dy = (short) (file.readFloat2() * 256);
					short dz = (short) (file.readFloat2() * 256);
					
					short x = (short) (file.readFloat2() * 32768);
					short y = (short) (file.readFloat2() * 32768);
					short z = (short) (file.readFloat2() * 32768);
					short w = (short) (file.readFloat2() * 32768);
					
					transKeyframes.add(new TransKeyframe(timestamp, dx, dy, dz));
					rotKeyframes.add(new RotKeyframe(timestamp, x, y, z, w));
				}
				
				timeAxes.add(new TimeAxis(transKeyframes, rotKeyframes));
			}
			
		} else {
			for (int i = 0; i < numTimeaxes; i++) {
				int numTranslateKeyframes = file.readInt2();
				
				List<TransKeyframe> transKeyframes = new ArrayList<TransKeyframe>();
				for (int j = 0; j < numTranslateKeyframes; j++) {
					int timestamp = file.readUnsignedByte();
					short dx = file.readSignedShort();
					short dy = file.readSignedShort();
					short dz = file.readSignedShort();
					
					transKeyframes.add(new TransKeyframe(timestamp, dx, dy, dz));
				}
				
				int numRotateKeyframes = file.readInt2();
				
				List<RotKeyframe> rotKeyframes = new ArrayList<RotKeyframe>();
				for (int j = 0; j < numRotateKeyframes; j++) {
					int timestamp = file.readUnsignedByte();
					short x = file.readSignedShort();
					short y = file.readSignedShort();
					short z = file.readSignedShort();
					short w = file.readSignedShort();
					
					rotKeyframes.add(new RotKeyframe(timestamp, x, y, z, w));
				}
				
				timeAxes.add(new TimeAxis(transKeyframes, rotKeyframes));
			}
		}
		
		// Animations
		List<Animation> animations = new ArrayList<Animation>();
		for (int i = 0; i < numAnimations; i++) {
			String name = file.readString(32);
			int unknown = file.readInt2(); // unknown
			file.readString(0x18); // unknown
			int numRelatedBones = file.readInt2();
			
			List<BoneAnimation> boneAnims = new ArrayList<BoneAnimation>();
			for (int j = 0; j < numRelatedBones; j++) {
				int boneId     = file.readInt2();
				int timeaxisId = file.readInt2();
				
				boneAnims.add(new BoneAnimation(boneId, timeaxisId));
			}
			
			animations.add(new Animation(name, unknown, boneAnims));
		}
		
		file.close();
		
		return new AbiFile(modelIdentifier, textures, bones, models, animations, timeAxes);
	}
}
