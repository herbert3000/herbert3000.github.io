package com.commandos.abiconverter.fileIO;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

import com.commandos.abiconverter.entities.AbiFile;
import com.commandos.abiconverter.entities.Border;
import com.commandos.abiconverter.entities.Model;
import com.commandos.abiconverter.entities.Polygon;
import com.commandos.abiconverter.entities.Texture;
import com.commandos.abiconverter.entities.Vertex;
import com.commandos.abiconverter.utils.Constants;
import com.commandos.abiconverter.utils.FileSystem;

public class ObjWriter {

	public static void writeObj(AbiFile abi, String filename) throws IOException {
		String foldername = filename + Constants.FOLDER_EXTENSION;
		FileSystem.createFolder(foldername);
		foldername += "\\Models";
		FileSystem.createFolder(foldername);
		
		FileOutputStream fos;
		BufferedOutputStream bos;
		OutputStreamWriter out;
		
		String mtlName = "Textures.mtl";
		fos = new FileOutputStream(new File(foldername + "\\" + mtlName));
		bos = new BufferedOutputStream(fos);
		out = new OutputStreamWriter(bos, "UTF-8");
		
		int index = 0;
		for (Texture t : abi.getTextures()) {
			out.write("newmtl " + index + "\r\n");
			out.write("Ka 1.000 1.000 1.000" + "\r\n");
			out.write("Kd 1.000 1.000 1.000" + "\r\n");
			out.write("illum 0" + "\r\n");
			out.write("map_Kd " + "..\\textures\\" + t.getName() + "\r\n\r\n");
			index++;
		}
		out.close();
		
		for (Model m : abi.getModels()) {
			fos = new FileOutputStream(new File(foldername + "\\" + m.getName() + ".obj"));
			out = new OutputStreamWriter(fos, "UTF-8");
			
			out.write("mtllib " + mtlName + "\r\n\r\n");
			
			for (Vertex v : m.getVertices()) {
				out.write("v " + v.toString() + "\r\n");
			}
			out.write("\r\n");
			
			for (Polygon p : m.getPolygons()) {
				for (int k = p.getNumBorders() - 1; k >= 0; k--) {
					Border b = p.getBorders().get(k);
					out.write("vt " + b.getU() + " " + b.getV()*-1 +"\r\n");
				}
			}
			out.write("\r\n");
			
			out.write("g " + m.getName() + "\r\n");
			
			int lastMat = -1;
			int uvCounter = 1;
			
			for (Polygon p : m.getPolygons()) {
				int mat = p.getTextureId();
				if (mat != lastMat) {
					out.write("usemtl " + mat + "\r\n");
					lastMat = mat;
				}
				out.write("f");
				
				for (int k = p.getNumBorders() - 1; k >= 0; k--) {
					Border b = p.getBorders().get(k);
					out.write(" " + (b.getId() + 1) + "/" + (uvCounter++));
				}
				out.write("\r\n");
			}
			
			out.close();
		}
	}
}
