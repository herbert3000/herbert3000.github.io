package com.commandos.abiconverter.fileIO;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class LittleEndianDataInputStream extends DataInputStream {

	public LittleEndianDataInputStream(String name) throws FileNotFoundException {
		super(new BufferedInputStream(new FileInputStream(name)));
	}
	
	public float readFloat2() throws IOException {
		return Float.intBitsToFloat(readInt2());
	}

	public int readInt2() throws IOException {
		byte w[] = new byte[4];
		readFully(w,0,4);
		return
			(w[3])		  << 24 |
			(w[2] & 0xFF) << 16 |
			(w[1] & 0xFF) <<  8 |
			(w[0] & 0xFF);
	}

	public short readShort2() throws IOException {
		short s = (short) (readUnsignedByte() | readUnsignedByte() << 8);
		return s;
	}

	public short readSignedShort() throws IOException {
		short s = readShort2();
		if (s > 32767) {
			s -= 65536;
		}
		return s;
	}

	public String readIdent() throws IOException {
		byte w[] = new byte[4];
		readFully(w, 0, 4);
		return new String(w);
	}

	public String readString(int numCharacters) throws IOException {
		String s = "";
		int i;
		for (i = 0; i < numCharacters; i++) {
			char b = (char) readUnsignedByte();
			if (b == 0) break;
			s += b;
		}
		skipBytes(numCharacters - i - 1);
		return s;
	}
}
