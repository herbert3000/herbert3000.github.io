package com.commandos.abiconverter.fileIO;

import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class LittleEndianDataOutputStream extends DataOutputStream {

	public LittleEndianDataOutputStream(String name) throws FileNotFoundException {
		super(new BufferedOutputStream(new FileOutputStream(name)));
	}

	public void writeFloat2(float f) throws IOException {
		int bits = Float.floatToIntBits(f);
		writeByte((byte)(bits & 0xFF));
		writeByte((byte)((bits >> 8) & 0xFF));
		writeByte((byte)((bits >> 16) & 0xFF));
		writeByte((byte)((bits >> 24) & 0xFF));
	}

	public void writeInt2(int i) throws IOException {
		int o = 
			(i & 0xFF000000) >> 24 |
			(i & 0x00FF0000) >>  8 |
			(i & 0x0000FF00) <<  8 |
			(i & 0x000000FF) << 24;
		writeInt(o);
	}

	public void writeShort2(int i) throws IOException {
		int o = 
			(i & 0xFF00) >> 8 |
			(i & 0x00FF) << 8;
		writeShort(o);
	}

	public void writeSignedShort(int i) throws IOException {
		int o = 
			(i & 0xFF00) >> 8 |
			(i & 0x00FF) << 8;
		if (o > 32767) {
			o -= 65536;
		}
		writeShort(o);
	}

	public void writeString(String s, int l) throws IOException {
		byte b[] = new byte[l];
		System.arraycopy(s.getBytes(), 0, b, 0, s.length());
		write(b);
	}

}
