package com.commandos.abiconverter.fileIO;

import java.io.File;
import java.io.IOException;

import com.commandos.abiconverter.entities.AbiFile;
import com.commandos.abiconverter.entities.Animation;
import com.commandos.abiconverter.entities.Bone;
import com.commandos.abiconverter.entities.BoneAnimation;
import com.commandos.abiconverter.entities.BoneIndex;
import com.commandos.abiconverter.entities.Border;
import com.commandos.abiconverter.entities.Model;
import com.commandos.abiconverter.entities.Polygon;
import com.commandos.abiconverter.entities.RotKeyframe;
import com.commandos.abiconverter.entities.Texture;
import com.commandos.abiconverter.entities.TimeAxis;
import com.commandos.abiconverter.entities.TransKeyframe;
import com.commandos.abiconverter.entities.Vertex;
import com.commandos.abiconverter.utils.Constants;
import com.commandos.abiconverter.utils.FileSystem;

public class AbiWriter {

	public void writeAbi(AbiFile abi, File f, int version) throws IOException {
		if (version == 1011) {
			writeAbi3(abi, f);
		}
		writeAbi2(abi, f, version);
	}

	public void writeAbi3(AbiFile abi, File f) throws IOException {
		String filename = f.getAbsolutePath();
		String foldername = filename + Constants.FOLDER_EXTENSION;
		FileSystem.createFolder(foldername);
		
		LittleEndianDataOutputStream file = new LittleEndianDataOutputStream(foldername + "\\" + f.getName());
		
		// ABI Header
	    file.writeBytes("LDMB");
	    file.writeBytes("1011");
	    file.writeShort2(0);
		
		file.writeShort2(abi.getNumTimeaxes());
		file.writeShort2(abi.getNumAnimations());
		file.writeShort2(abi.getNumTextures());
		file.writeShort2(abi.getNumModels());
		file.writeShort2(abi.getNumBones());
		
		file.writeInt2(abi.getOffsetTexture());
		file.writeInt2(abi.getOffsetModel());
		file.writeInt2(abi.getOffsetAnimationHeader());
		file.writeInt2(abi.getSizeBoneTrans());
		file.writeInt2(abi.getSizeTimeaxis());
		
		// Texture Header
		for (Texture t : abi.getTextures()) {
			file.writeShort2(t.getWidth());
			file.writeShort2(t.getHeight());
			file.write(t.getPalette());
			file.writeString(t.getName(), 32);
			int texId = t.getTextureId();
			if (texId == 0) {
				// Create random texture id
				texId = (int) Math.abs(Math.random()*0x7F000000 + 0xFFFFFF);
			}
			file.writeInt2(texId);
			file.writeInt2(abi.getOffsetTexture() + t.getRelativeTextureOffset());
		}
		
		// Bones
		for (Bone b : abi.getBones()) {
			file.writeInt2(b.getParent());
			file.writeInt2(b.getUnknown()); // UNKNWON BONE00
			file.writeFloat2(b.getTransformX());
			file.writeFloat2(b.getTransformY());
			file.writeFloat2(b.getTransformZ());
			file.writeString(b.getName(), 32);
		}
		
		// Model Header
		for (Model m : abi.getModels()) {
			file.writeShort2(m.getNumVertices());
			file.writeShort2(m.getNumPolygons());
			file.writeShort2(m.getSumNumBorders());
			file.writeString(m.getName(), 32);
			file.writeInt2(abi.getOffsetModel() + m.getRelativeModelOffset());
		}
		
		// Animation Header
		for (Animation a : abi.getAnimations()) {
			file.writeString(a.getName(), 32);
			file.writeInt2(a.getUnknown()); // unknown
			file.writeInt2(0); // unknown, always 0
			file.writeInt2(0); // unknown, always 0
			file.writeInt2(0); // unknown, always 0
			file.writeInt2(0); // unknown, always 0
		}
		
		// Bone Transformations
		for (Animation a : abi.getAnimations()) {
			file.writeInt2(a.getNumRelatedBones());
			
			for (BoneAnimation b : a.getBoneAnimations()) {
				file.writeInt2(b.getBoneId());
				file.writeInt2(b.getTimeaxisId());
			}
		}
		
		// TimeAxis
		for (TimeAxis t : abi.getTimeAxes()) {
			int numTransKf = t.getNumTransKeyframes();
			int numRotKf = t.getNumRotKeyframes();
			
			file.writeByte(numTransKf);
			file.writeByte(numRotKf);
			
			for (TransKeyframe tk : t.getTransKeyframes()) {
				file.writeSignedShort(tk.getDx());
				file.writeSignedShort(tk.getDy());
				file.writeSignedShort(tk.getDz());
			}
			
			for (TransKeyframe tk : t.getTransKeyframes()) {
				file.writeByte(tk.getTimestamp());
			}
			
			for (RotKeyframe rk : t.getRotKeyframes()) {
				file.writeByte((byte) (rk.getX() / 256.0));
				file.writeByte((byte) (rk.getY() / 256.0));
				file.writeByte((byte) (rk.getZ() / 256.0));
			}
			
			for (RotKeyframe rk : t.getRotKeyframes()) {
				file.writeByte(rk.getTimestamp());
			}
			
			if (numTransKf % 2 != 0) {
				file.writeByte(0x64);
			}
		}
		
		// Texture
		for (Texture t : abi.getTextures()) {
			file.write(t.getPixelData());
		}
		
		// Model
		for (Model m : abi.getModels()) {
			for (Vertex v : m.getVertices()) {
				file.writeFloat2(v.getX());
				file.writeFloat2(v.getY());
				file.writeFloat2(v.getZ());
			}
			
			for (Polygon p : m.getPolygons()) {
				int numBorders = p.getNumBorders();
				int textureId = p.getTextureId();
				
				file.writeByte(numBorders);
				file.writeShort2(textureId);
				
				for (Border b : p.getBorders()) {
					file.writeShort2(b.getId());
					file.writeShort2((short)(b.getU() * 4096));
					file.writeShort2((short)(b.getV() * 4096));
				}
			}
			
			for (BoneIndex b : m.getRelatedBones()) {
				file.writeInt2(b.getStartIndex());
				file.writeInt2(b.getEndIndex());
			}
		}
		
		file.close();
	}

	public void writeAbi2(AbiFile abi, File f, int version) throws IOException {
		String filename = f.getAbsolutePath();
		String foldername = filename + Constants.FOLDER_EXTENSION;
		FileSystem.createFolder(foldername);
		
		LittleEndianDataOutputStream file = new LittleEndianDataOutputStream(foldername + "\\" + f.getName());
		
		// ABI Header
	    file.writeBytes("LDMB");
	    file.writeBytes(new String("" + version));
	    
	    file.writeInt2(abi.getNumTimeaxes());
		file.writeInt2(abi.getNumAnimations());
		file.writeInt2(abi.getNumTextures());
		
		// Textures
		for (Texture t : abi.getTextures()) {
			file.writeInt2(t.getIdentifier()); // unknown, always 0
			file.writeInt2(t.getWidth());
			file.writeInt2(t.getHeight());
			file.writeString(t.getName(), 32);
			file.write(t.getPalette());
			file.write(t.getPixelData());
		}
		
		// Model & Bone Header
		if (version == 1060) {
			file.writeByte(abi.getModelIdentifier());
		}
		file.writeInt2(abi.getNumModels());
		file.writeInt2(abi.getNumBones());
		
		// Models
		for (Model m : abi.getModels()) {
			file.writeInt2(m.getNumVertices());
			file.writeInt2(m.getNumPolygons());
			file.writeString(m.getName(), 32);
			
			for (Vertex v : m.getVertices()) {
				file.writeFloat2(v.getX());
				file.writeFloat2(v.getY());
				file.writeFloat2(v.getZ());
			}
			
			for (Polygon p : m.getPolygons()) {
				int numBorders = p.getNumBorders();
				int textureId = p.getTextureId();
				
				if (version == 1040) {
					file.writeInt2(numBorders);
					file.writeInt2(textureId);
				} else {
					file.writeByte(numBorders);
					file.writeByte(textureId);
				}
				
				if (version == 1040) {
					for (Border b : p.getBorders()) {
						file.writeInt2(b.getId());
						file.writeFloat2(b.getU());
						file.writeFloat2(b.getV());
					}
				} else {
					for (Border b : p.getBorders()) {
						file.writeShort2(b.getId());
						file.writeShort2((short) (b.getU() * 4096));
						file.writeShort2((short) (b.getV() * 4096));
					}
				}
			}
			
			for (BoneIndex b : m.getRelatedBones()) {
				file.writeInt2(b.getStartIndex());
				file.writeInt2(b.getEndIndex());
			}
		}
		
		// Bones
		for (Bone b : abi.getBones()) {
			file.writeInt2(b.getParent());
			file.writeFloat2(b.getTransformX());
			file.writeFloat2(b.getTransformY());
			file.writeFloat2(b.getTransformZ());
			file.writeString(b.getName(), 32);
			file.writeInt2(b.getUnknown()); // unknown, always 0
		}
		
		// Time Axes
		if (version == 1040) {
			file.writeInt2(abi.getNumTimeaxes());
			
			for (TimeAxis t : abi.getTimeAxes()) {
				int numFrames = t.getNumTransKeyframes();
				
				for (int i = 0; i < numFrames; i++) {
					TransKeyframe tk = t.getTransKeyframes().get(i);
					RotKeyframe rk = t.getRotKeyframes().get(i);
					
					file.writeFloat2(tk.getTimestamp());
					file.writeInt2(3); // unknown
					
					file.writeFloat2((float) (tk.getDx() / 256.0));
					file.writeFloat2((float) (tk.getDy() / 256.0));
					file.writeFloat2((float) (tk.getDz() / 256.0));
					
					file.writeFloat2((float) (rk.getX() / 32768.0));
					file.writeFloat2((float) (rk.getY() / 32768.0));
					file.writeFloat2((float) (rk.getZ() / 32768.0));
					file.writeFloat2((float) (rk.getW() / 32768.0));
				}
			}
			
		} else {
			for (TimeAxis t : abi.getTimeAxes()) {
				
				file.writeInt2(t.getNumTransKeyframes());
				
				for (TransKeyframe tk : t.getTransKeyframes()) {
					file.writeByte(tk.getTimestamp());
					file.writeSignedShort(tk.getDx());
					file.writeSignedShort(tk.getDy());
					file.writeSignedShort(tk.getDz());
				}
				
				file.writeInt2(t.getNumRotKeyframes());
				
				for (RotKeyframe rk : t.getRotKeyframes()) {
					file.writeByte(rk.getTimestamp());
					file.writeSignedShort(rk.getX());
					file.writeSignedShort(rk.getY());
					file.writeSignedShort(rk.getZ());
					file.writeSignedShort(rk.getW());
				}
			}
		}
		
		// Animations
		for (Animation a : abi.getAnimations()) {
			file.writeString(a.getName(), 32);
			file.writeInt2(a.getUnknown());
			
			// unknown values
			file.writeInt2(-1);
			file.writeInt2(-1);
			file.writeInt2(0);
			file.writeInt2(0);
			file.writeInt2(0);
			file.writeInt2(0);
			
			file.writeInt2(a.getNumRelatedBones());
			
			for (BoneAnimation b : a.getBoneAnimations()) {
				file.writeInt2(b.getBoneId());
				file.writeInt2(b.getTimeaxisId());
			}
		}
		
		file.close();
	}
}
