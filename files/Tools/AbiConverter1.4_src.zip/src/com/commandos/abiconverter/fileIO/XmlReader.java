package com.commandos.abiconverter.fileIO;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.commandos.abiconverter.entities.AbiFile;
import com.commandos.abiconverter.entities.Animation;
import com.commandos.abiconverter.entities.Bone;
import com.commandos.abiconverter.entities.BoneAnimation;
import com.commandos.abiconverter.entities.BoneIndex;
import com.commandos.abiconverter.entities.Border;
import com.commandos.abiconverter.entities.Model;
import com.commandos.abiconverter.entities.Polygon;
import com.commandos.abiconverter.entities.RotKeyframe;
import com.commandos.abiconverter.entities.Texture;
import com.commandos.abiconverter.entities.TimeAxis;
import com.commandos.abiconverter.entities.TransKeyframe;
import com.commandos.abiconverter.entities.Vertex;
import com.commandos.abiconverter.xml.IXmlReader;
import com.commandos.abiconverter.xml.SimpleXmlReader;
import com.commandos.abiconverter.xml.XmlException;

public class XmlReader {

	private IXmlReader xmlReader;

	public AbiFile readAbiFile() throws XmlException {
		
		byte modelIdentifier = readModelFlag();
		List<Texture> textures = readTextures();
		List<Bone> bones = readBones();
		List<Model> models = readModels();
		List<Animation> animations = readAnimations();
		List<TimeAxis> timeAxes = readTimeAxes();
		
		return new AbiFile(modelIdentifier, textures, bones, models, animations, timeAxes);
	}

	public int readVersion() throws XmlException {
		String version = xmlReader.getValue("Version");
		return Integer.parseInt(version);
	}

	public byte readModelFlag() throws XmlException {
		String version = xmlReader.getValue("ModelFlag");
		return (byte) Integer.parseInt(version);
	}

	public List<Animation> readAnimations() throws XmlException {
		
		List<Animation> animations = new ArrayList<Animation>();
		NodeList nodes = xmlReader.getNodes("Animation");
		
		for (int i = 0; i < nodes.getLength(); i++) {
			String name = null;
			List<BoneAnimation> boneAnims = new ArrayList<BoneAnimation>();
			
			Node node = nodes.item(i);
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				Element element = (Element) node;
				
				NodeList childNodes = element.getChildNodes();
				for (int j = 0; j < childNodes.getLength(); j++) {
					Node child = childNodes.item(j);
					String nodeName = child.getNodeName();
					
					if (nodeName.equals("Name")) {
						name = child.getFirstChild().getNodeValue();
					} else if (nodeName.equals("BoneAnimationEntries")) {
						NodeList animationNodes = child.getChildNodes();
						for (int k = 0; k < animationNodes.getLength(); k++) {
							Node animationNode = animationNodes.item(k);
							if (animationNode.getNodeType() == Node.ELEMENT_NODE) {
								NodeList attributesNodes = animationNode.getChildNodes();
								
								int boneIndex = 0;
								int timeAxisIndex = 0;
								
								for (int m = 0; m < attributesNodes.getLength(); m++) {
									Node attributesNode = attributesNodes.item(m);
									nodeName = attributesNode.getNodeName();
									if (nodeName.equals("BoneIndex")) {
										String value = attributesNode.getFirstChild().getNodeValue();
										boneIndex = Integer.parseInt(value);
									} else if (nodeName.equals("TimeAxisIndex")) {
										String value = attributesNode.getFirstChild().getNodeValue();
										timeAxisIndex = Integer.parseInt(value);
									}
								}
								boneAnims.add(new BoneAnimation(boneIndex, timeAxisIndex));
							}
						}
					}
				}
			}
			animations.add(new Animation(name, boneAnims));
		}
		
		return animations;
	}

	public List<TimeAxis> readTimeAxes() throws XmlException {
		
		List<TimeAxis> timeAxes = new ArrayList<TimeAxis>();
		NodeList nodes = xmlReader.getNodes("TransformationTimeAxis");
		
		for (int i = 0; i < nodes.getLength(); i++) {
			List<TransKeyframe> transKeyframes = new ArrayList<TransKeyframe>();
			List<RotKeyframe> rotKeyframes = new ArrayList<RotKeyframe>();
			
			Node node = nodes.item(i);
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				Element element = (Element) node;
				
				NodeList childNodes = element.getChildNodes();
				for (int j = 0; j < childNodes.getLength(); j++) {
					Node child = childNodes.item(j);
					String nodeName = child.getNodeName();
					
					if (nodeName.equals("TranslationKeyframes")) {
						NodeList transNodes = child.getChildNodes();
						for (int k = 0; k < transNodes.getLength(); k++) {
							Node transNode = transNodes.item(k);
							
							int timestamp = 0;
							short dx = 0, dy = 0, dz = 0;
							
							if (transNode.getNodeType() == Node.ELEMENT_NODE) {
								NodeList attributesNodes = transNode.getChildNodes();
								for (int m = 0; m < attributesNodes.getLength(); m++) {
									Node attributesNode = attributesNodes.item(m);
									nodeName = attributesNode.getNodeName();
									if (nodeName.equals("Timestamp")) {
										String value = attributesNode.getFirstChild().getNodeValue();
										timestamp = Integer.parseInt(value);
									} else if (nodeName.equals("Dx")) {
										String value = attributesNode.getFirstChild().getNodeValue();
										dx = (short) Integer.parseInt(value);
									} else if (nodeName.equals("Dy")) {
										String value = attributesNode.getFirstChild().getNodeValue();
										dy = (short) Integer.parseInt(value);
									} else if (nodeName.equals("Dz")) {
										String value = attributesNode.getFirstChild().getNodeValue();
										dz = (short) Integer.parseInt(value);
									}
								}
							}
							transKeyframes.add(new TransKeyframe(timestamp, dx, dy, dz));
						}
					} else if (nodeName.equals("RotationKeyframes")) {
						NodeList rotNodes = child.getChildNodes();
						for (int k = 0; k < rotNodes.getLength(); k++) {
							Node rotNode = rotNodes.item(k);
							
							int timestamp = 0;
							short x = 0, y = 0, z = 0, w = 0;
							
							if (rotNode.getNodeType() == Node.ELEMENT_NODE) {
								NodeList attributesNodes = rotNode.getChildNodes();
								for (int m = 0; m < attributesNodes.getLength(); m++) {
									Node attributesNode = attributesNodes.item(m);
									nodeName = attributesNode.getNodeName();
									if (nodeName.equals("Timestamp")) {
										String value = attributesNode.getFirstChild().getNodeValue();
										timestamp = Integer.parseInt(value);
									} else if (nodeName.equals("X")) {
										String value = attributesNode.getFirstChild().getNodeValue();
										x = (short) Integer.parseInt(value);
									} else if (nodeName.equals("Y")) {
										String value = attributesNode.getFirstChild().getNodeValue();
										y = (short) Integer.parseInt(value);
									} else if (nodeName.equals("Z")) {
										String value = attributesNode.getFirstChild().getNodeValue();
										z = (short) Integer.parseInt(value);
									} else if (nodeName.equals("W")) {
										String value = attributesNode.getFirstChild().getNodeValue();
										w = (short) Integer.parseInt(value);
									}
								}
							}
							rotKeyframes.add(new RotKeyframe(timestamp, x, y, z, w));
						}
					}
				}
			}
			timeAxes.add(new TimeAxis(transKeyframes, rotKeyframes));
		}
		
		return timeAxes;
	}

	public List<Bone> readBones() throws XmlException {
		
		List<Bone> bones = new ArrayList<Bone>();
		NodeList nodes = xmlReader.getNodes("Bone");
		
		for (int i = 0; i < nodes.getLength(); i++) {
			String name = null;
			int parent = 0, unknown = 0;
			float x = 0, y = 0, z = 0;
			
			Node node = nodes.item(i);
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				Element element = (Element) node;
				
				NodeList childNodes = element.getChildNodes();
				for (int j = 0; j < childNodes.getLength(); j++) {
					Node child = childNodes.item(j);
					String nodeName = child.getNodeName();
					
					if (nodeName.equals("Name")) {
						name = child.getFirstChild().getNodeValue();
					} else if (nodeName.equals("ParentIndex")) {
						String value = child.getFirstChild().getNodeValue();
						parent = Integer.parseInt(value);
					} else if (nodeName.equals("BoneUnknown")) {
						String value = child.getFirstChild().getNodeValue();
						unknown = Integer.parseInt(value);
					} else if (nodeName.equals("TransformationMatrix")) {
						NodeList xyzNodes = child.getChildNodes();
						for (int m = 0; m < xyzNodes.getLength(); m++) {
							Node xyzNode = xyzNodes.item(m);
							
							if (xyzNode.getNodeName().equals("X")) {
								x = Float.parseFloat(xyzNode.getFirstChild().getNodeValue());
							} else if (xyzNode.getNodeName().equals("Y")) {
								y = Float.parseFloat(xyzNode.getFirstChild().getNodeValue());
							} else if (xyzNode.getNodeName().equals("Z")) {
								z = Float.parseFloat(xyzNode.getFirstChild().getNodeValue());
							}
						}
					} 
				}
			}
			bones.add(new Bone(parent, x, y, z, name, unknown));
		}
		return bones;
	}

	public List<Model> readModels() throws XmlException {
		
		List<Model> models = new ArrayList<Model>();
		NodeList nodes = xmlReader.getNodes("Model");
		int sizeModel = 0;
		
		for (int i = 0; i < nodes.getLength(); i++) {
			String name = null;
			List<Vertex> vertices = new ArrayList<Vertex>();
			List<Polygon> polygons = new ArrayList<Polygon>();
			List<BoneIndex> relatedBones = new ArrayList<BoneIndex>();
			
			Node node = nodes.item(i);
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				Element element = (Element) node;
				
				NodeList childNodes = element.getChildNodes();
				for (int j = 0; j < childNodes.getLength(); j++) {
					Node child = childNodes.item(j);
					String nodeName = child.getNodeName();
					
					if (nodeName.equals("Name")) {
						name = child.getFirstChild().getNodeValue();
					} else if (nodeName.equals("Vertices")) {
						NodeList vertexNodes = child.getChildNodes();
						for (int k = 0; k < vertexNodes.getLength(); k++) {
							Node vertexNode = vertexNodes.item(k);
							if (vertexNode.getNodeType() == Node.ELEMENT_NODE) {
								NodeList xyzNodes = vertexNode.getChildNodes();
								for (int m = 0; m < xyzNodes.getLength(); m++) {
									Node xyzNode = xyzNodes.item(m);
									float x = 0, y = 0, z = 0;
									
									if (xyzNode.getNodeName().equals("X")) {
										x = Float.parseFloat(xyzNode.getFirstChild().getNodeValue());
									} else if (xyzNode.getNodeName().equals("Y")) {
										y = Float.parseFloat(xyzNode.getFirstChild().getNodeValue());
									} else if (xyzNode.getNodeName().equals("Z")) {
										z = Float.parseFloat(xyzNode.getFirstChild().getNodeValue());
									}
									vertices.add(new Vertex(x, y, z));
								}
							}
						}
					} else if (nodeName.equals("Polygons")) {
						NodeList polygonNodes = child.getChildNodes();
						for (int k = 0; k < polygonNodes.getLength(); k++) {
							int textureId = 0;
							List<Border> borders = new ArrayList<Border>();
							
							Node polygonNode = polygonNodes.item(k);
							if (polygonNode.getNodeType() == Node.ELEMENT_NODE) {
								NodeList attributeNodes = polygonNode.getChildNodes();
								for (int m = 0; m < attributeNodes.getLength(); m++) {
									Node attributeNode = attributeNodes.item(m);
									if (attributeNode.getNodeName().equals("TextureIndex")) {
										textureId = Integer.parseInt(attributeNode.getFirstChild().getNodeValue());
									} else if (attributeNode.getNodeName().equals("Vertices")) {
										NodeList vertexNodes = attributeNode.getChildNodes();
										for (int n = 0; n < vertexNodes.getLength(); n++) {
											Node vertexNode = vertexNodes.item(n);
											NodeList vertexInfoNodes = vertexNode.getChildNodes();
											for (int p = 0; p < vertexInfoNodes.getLength(); p++) {
												Node vertexInfoNode = vertexInfoNodes.item(p);
												int index = 0;
												float u = 0, v = 0;
												
												if (vertexInfoNode.getNodeName().equals("VertexIndex")) {
													index = Integer.parseInt(vertexInfoNode.getFirstChild().getNodeValue());
												} else if (vertexInfoNode.getNodeName().equals("U")) {
													u = Float.parseFloat(vertexInfoNode.getFirstChild().getNodeValue());
												} else if (vertexInfoNode.getNodeName().equals("V")) {
													v = Float.parseFloat(vertexInfoNode.getFirstChild().getNodeValue());
												}
												borders.add(new Border(index, u, v));
											}
										}
									}
								}
							}
							polygons.add(new Polygon(textureId, borders));
						}
					} else if (nodeName.equals("VerticesToBone")) {
						NodeList vertexNodes = child.getChildNodes();
						for (int k = 0; k < vertexNodes.getLength(); k++) {
							Node vertexNode = vertexNodes.item(k);
							if (vertexNode.getNodeType() == Node.ELEMENT_NODE) {
								NodeList xyzNodes = vertexNode.getChildNodes();
								for (int m = 0; m < xyzNodes.getLength(); m++) {
									Node xyzNode = xyzNodes.item(m);
									int startIndex = 0, endIndex = 0;
									
									if (xyzNode.getNodeName().equals("StartVertexIndex")) {
										startIndex = Integer.parseInt(xyzNode.getFirstChild().getNodeValue());
									} else if (xyzNode.getNodeName().equals("EndVertexIndex")) {
										endIndex = Integer.parseInt(xyzNode.getFirstChild().getNodeValue());
									}
									relatedBones.add(new BoneIndex(startIndex, endIndex));
								}
							}
						}
					}
				}
			}
			 
			int relativeModelOffset = sizeModel;
			Model m = new Model(name, vertices, polygons, relatedBones, relativeModelOffset);
			sizeModel += m.getSizeModel();
		}
		return models;
	}

	public List<Texture> readTextures() throws XmlException {
		
		String folderName = xmlReader.getPath() + "\\Textures";
		int sizeTexture = 0;
		
		List<Texture> textures = new ArrayList<Texture>();
		NodeList nodes = xmlReader.getNodes("Texture");
		
		for (int i = 0; i < nodes.getLength(); i++) {
			Node node = nodes.item(i);
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				Element element = (Element) node;
				String name = xmlReader.getValue("Name", element);
				String id   = xmlReader.getValue("TextureId", element);
				int relativeTextureOffset = sizeTexture;
				
				Texture texture = null;
				try {
					texture = new Texture(folderName, name, relativeTextureOffset, Integer.parseInt(id));
				} catch (IOException e) {
					throw new XmlException(e.getMessage());
				}
				textures.add(texture);
				
				sizeTexture += texture.getWidth() * texture.getHeight();
			}
		}
		return textures;
	}

	public XmlReader(File file) {
		try {
			xmlReader = new SimpleXmlReader(file);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
