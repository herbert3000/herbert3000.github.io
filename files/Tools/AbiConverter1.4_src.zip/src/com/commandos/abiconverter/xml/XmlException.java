package com.commandos.abiconverter.xml;

public class XmlException extends Exception {

	private static final long serialVersionUID = 1201656469081977383L;

	public XmlException() {}

	public XmlException(String message) {
		super(message);
	}
}
