package com.commandos.abiconverter.xml;

import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public interface IXmlReader {
	NodeList getNodes(String tag);
	String getValue(String tag) throws XmlException;
	String getValue(String tag, Element element) throws XmlException;
	String getPath();
}
