package com.commandos.abiconverter.xml;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class SimpleXmlReader implements IXmlReader {

	private String path;
	private Document doc;

	public SimpleXmlReader(File xmlFile) throws IOException {
		String absolutePath = xmlFile.getAbsolutePath();
		path = absolutePath.substring(0, absolutePath.lastIndexOf(File.separator));
		
		try {
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder;
			dBuilder = dbFactory.newDocumentBuilder();
			doc = dBuilder.parse(xmlFile);
			doc.getDocumentElement().normalize();
			
			// TODO:
			/*
			NodeList nodes = doc.getElementsByTagName("stock");
			for (int i = 0; i < nodes.getLength(); i++) {
				Node node = nodes.item(i);

				if (node.getNodeType() == Node.ELEMENT_NODE) {
					Element element = (Element) node;
					System.out.println("Stock Symbol: " + getValue("symbol", element));
					System.out.println("Stock Price: " + getValue("price", element));
					System.out.println("Stock Quantity: " + getValue("quantity", element));
				}
			}
			*/
		} catch (ParserConfigurationException | SAXException e) {
			throw new IOException(e);
		}
	}

	@Override
	public NodeList getNodes(String tag) {
		NodeList nodes = doc.getElementsByTagName(tag);
		return nodes;
	}

	@Override
	public String getValue(String tag, Element element) throws XmlException {
		NodeList nodes = element.getElementsByTagName(tag).item(0).getChildNodes();
		if (nodes.getLength() == 0) {
			throw new XmlException("No such element: " + tag);
		}
		Node node = (Node) nodes.item(0);
		return node.getNodeValue();
	}

	@Override
	public String getValue(String tag) throws XmlException {
		NodeList nodes = getNodes(tag);
		if (nodes.getLength() != 1) {
			throw new XmlException("No such element: " + tag);
		}
		Node node = nodes.item(0);
		return node.getTextContent();
	}

	@Override
	public String getPath() {
		return path;
	}
}
