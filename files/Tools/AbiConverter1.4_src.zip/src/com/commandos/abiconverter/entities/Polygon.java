package com.commandos.abiconverter.entities;

import java.util.List;

public class Polygon {

	private int textureId;
	private List<Border> borders;

	public Polygon(int textureId, List<Border> borders) {
		this.textureId = textureId;
		this.borders = borders;
	}

	public int getNumBorders() {
		return borders.size();
	}

	public int getTextureId() {
		return textureId;
	}

	public List<Border> getBorders() {
		return borders;
	}

	public int length() {
		return (3 + borders.size() * 6);
	}
}
