package com.commandos.abiconverter.entities;

import java.util.List;

public class Model {

	private String name;
	private List<Vertex> vertices;
	private List<Polygon> polygons;
	private List<BoneIndex> relatedBones;
	private int offset;
	private int sumNumBorders = 0;

	public Model(String name, List<Vertex> vertices, List<Polygon> polygons, List<BoneIndex> b, int offset) {
		this.name = name;
		this.vertices = vertices;
		this.polygons = polygons;
		this.relatedBones = b;
		this.offset = offset;
	}

	public int getNumVertices() {
		return vertices.size();
	}

	public int getNumPolygons() {
		return polygons.size();
	}

	public String getName() {
		return name;
	}

	public List<Vertex> getVertices() {
		return vertices;
	}

	public List<Polygon> getPolygons() {
		return polygons;
	}

	public List<BoneIndex> getRelatedBones() {
		return relatedBones;
	}

	public int getRelativeModelOffset() {
		return offset;
	}

	public int length() {
		int len = vertices.size() * 12;
		
		for (Polygon p : polygons) {
			len += p.length();
		}
		return len;
	}

	public int getSumNumBorders() {
		if (sumNumBorders == 0) {
			for (Polygon p : polygons) {
				sumNumBorders += p.getNumBorders();
			}
		}
		return sumNumBorders;
	}

	public int getSizeModel() {
		return relatedBones.size() * 8 + length();
	}
}
