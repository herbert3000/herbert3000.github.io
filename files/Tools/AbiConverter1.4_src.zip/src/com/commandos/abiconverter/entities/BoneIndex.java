package com.commandos.abiconverter.entities;

public class BoneIndex {

	private int startIndex;
	private int endIndex;

	public BoneIndex(int startIndex, int endIndex) {
		this.startIndex = startIndex;
		this.endIndex = endIndex;
	}

	public int getStartIndex() {
		return startIndex;
	}

	public int getEndIndex() {
		return endIndex;
	}
}
