package com.commandos.abiconverter.entities;

import java.util.List;

import com.commandos.abiconverter.utils.Constants;

public class AbiFile {

	private byte modelIdentifier;
	private List<Texture> textures;
	private List<Model> models;
	private List<Bone> bones;
	private List<TimeAxis> timeAxes;
	private List<Animation> animations;

	private int sizeBoneTrans = 0;
	private int sizeTimeaxis = 0;
	private int sizeTexture = 0;
	private int sizeModel = 0;

	public AbiFile(byte modelIdentifier, List<Texture> textures, List<Bone> bones, List<Model> models,
			List<Animation> animations, List<TimeAxis> timeAxes) {
		this.modelIdentifier = modelIdentifier;
		this.textures = textures;
		this.bones = bones;
		this.models = models;
		this.animations = animations;
		this.timeAxes = timeAxes;
	}

	public int getNumTimeaxes() {
		return timeAxes.size();
	}

	public int getNumAnimations() {
		return animations.size();
	}

	public int getNumTextures() {
		return textures.size();
	}

	public int getNumModels() {
		return models.size();
	}

	public int getNumBones() {
		return bones.size();
	}

	public byte getModelIdentifier() {
		return modelIdentifier;
	}

	public List<Texture> getTextures() {
		return textures;
	}

	public List<Model> getModels() {
		return models;
	}

	public List<Bone> getBones() {
		return bones;
	}

	public List<TimeAxis> getTimeAxes() {
		return timeAxes;
	}

	public List<Animation> getAnimations() {
		return animations;
	}

	public int getSizeTextureHeader() {
		return getNumTextures() * 0x32C;
	}

	public int getSizeBone() {
		return getNumBones() * 0x34;
	}

	public int getSizeModelHeader() {
		return getNumModels() * 0x2A;
	}

	public int getSizeAnimationHeader() {
		return getNumAnimations() * 0x34;
	}

	public int getSizeBoneTrans() {
		if (sizeBoneTrans == 0) {
			for (Animation m : animations) {
				sizeBoneTrans += (4 + m.getNumRelatedBones() * 8);
			}
		}
		return sizeBoneTrans;
	}

	public int getSizeTimeaxis() {
		if (sizeTimeaxis == 0) {
			for (TimeAxis ta : timeAxes) {
				sizeTimeaxis += (2 + ta.getNumTransKeyframes() * 7 + ta.getNumRotKeyframes() * 4);
				if (ta.getNumTransKeyframes() % 2 != 0) {
					sizeTimeaxis++;
				}
			}
		}
		return sizeTimeaxis;
	}

	public int getSizeTexture() {
		if (sizeTexture == 0) {
			for (Texture t : textures) {
				sizeTexture += (t.getWidth() * t.getHeight());
			}
		}
		return sizeTexture;
	}

	public int getSizeModel() {
		if (sizeModel == 0) {
			for (Model m : models) {
				sizeModel += (getNumBones() * 8) + m.length();
			}
		}
		return sizeModel;
	}

	public int getOffsetAnimationHeader() {
		return Constants.SIZE_ABI_HEADER + getSizeTextureHeader() + getSizeBone() + getSizeModelHeader();
	}

	public int getOffsetBoneTrans() {
		return getOffsetAnimationHeader() + getSizeAnimationHeader();
	}

	public int getOffsetTimeaxis() {
		return  getOffsetBoneTrans() + getSizeBoneTrans();
	}

	public int getOffsetTexture() {
		return getOffsetTimeaxis() + getSizeTimeaxis();
	}

	public int getOffsetModel() {
		return getOffsetTexture() + getSizeTexture();
	}
}
