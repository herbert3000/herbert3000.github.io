package com.commandos.abiconverter.entities;

import java.util.List;

public class Animation {
	
	private String name;
	private int unknown = 0;
	private List<BoneAnimation> boneAnims;

	public Animation(String name, int unknown, List<BoneAnimation> boneAnims) {
		this.name = name;
		this.unknown = unknown;
		this.boneAnims = boneAnims;
	}

	public Animation(String name, List<BoneAnimation> boneAnims) {
		this.name = name;
		this.boneAnims = boneAnims;
	}

	public Animation(String name, int unknown) {
		this.name = name;
		this.unknown = unknown;
	}

	public void setBoneAnimation(List<BoneAnimation> boneAnims) {
		this.boneAnims = boneAnims;
	}

	public String getName() {
		return name;
	}

	public int getUnknown() {
		return unknown;
	}

	public int getNumRelatedBones() {
		return boneAnims.size();
	}

	public List<BoneAnimation> getBoneAnimations() {
		return boneAnims;
	}
}
