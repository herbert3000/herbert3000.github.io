package com.commandos.abiconverter.entities;

public class Bone {

	private int parent;
	private float transformX;
	private float transformY;
	private float transformZ;
	private String name;
	private int unknown;

	public Bone(int parent, float x, float y, float z, String name, int unknown) {
		this.parent = parent;
		transformX = x;
		transformY = y;
		transformZ = z;
		this.name = name;
		this.unknown = unknown;
	}

	public int getParent() {
		return parent;
	}

	public float getTransformX() {
		return transformX;
	}

	public float getTransformY() {
		return transformY;
	}

	public float getTransformZ() {
		return transformZ;
	}

	public String getName() {
		return name;
	}

	public int getUnknown() {
		return unknown;
	}
}
