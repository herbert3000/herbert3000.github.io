package com.commandos.abiconverter.entities;

import java.util.List;

public class TimeAxis {

	private List<TransKeyframe> transKeyframes;
	private List<RotKeyframe> rotKeyframes;

	public TimeAxis(List<TransKeyframe> transKeyframes, List<RotKeyframe> rotKeyframes) {
		this.transKeyframes = transKeyframes;
		this.rotKeyframes = rotKeyframes;
	}

	public int getNumTransKeyframes() {
		return transKeyframes.size();
	}

	public int getNumRotKeyframes() {
		return rotKeyframes.size();
	}

	public List<TransKeyframe> getTransKeyframes() {
		return transKeyframes;
	}

	public List<RotKeyframe> getRotKeyframes() {
		return rotKeyframes;
	}
}
