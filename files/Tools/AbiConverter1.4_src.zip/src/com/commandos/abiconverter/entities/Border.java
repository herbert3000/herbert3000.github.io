package com.commandos.abiconverter.entities;

public class Border {

	private int id;
	private float u;
	private float v;

	public Border(int id, float u, float v) {
		this.id = id;
		this.u = u;
		this.v = v;
	}

	public int getId() {
		return id;
	}

	public float getU() {
		return u;
	}

	public float getV() {
		return v;
	}
}
