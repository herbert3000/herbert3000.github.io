package com.commandos.abiconverter.entities;

public class RotKeyframe {
	
	private int timestamp;
	private short x;
	private short y;
	private short z;
	private short w;
	
	public RotKeyframe(int timestamp, short x, short y, short z, short w) {
		this.timestamp = timestamp;
		this.x = x;
		this.y = y;
		this.z = z;
		this.w = w;
	}
	
	public RotKeyframe(byte rx, byte ry, byte rz) {
		this.x = (short) (rx * 256);
		this.y = (short) (ry * 256);
		this.z = (short) (rz * 256);
		this.w = (short) (Math.sqrt(16384 - rx*rx - ry*ry - rz*rz) * 256);
	}
	
	public void setTimestamp(int timestamp) {
		this.timestamp = timestamp;
	}
	
	public int getTimestamp() {
		return timestamp;
	}
	
	public short getX() {
		return x;
	}
	
	public short getY() {
		return y;
	}
	
	public short getZ() {
		return z;
	}
	
	public short getW() {
		return w;
	}
	
}
