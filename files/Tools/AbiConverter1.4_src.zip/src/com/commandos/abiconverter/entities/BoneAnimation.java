package com.commandos.abiconverter.entities;

public class BoneAnimation {

	private int boneId;
	private int timeaxisId;

	public BoneAnimation(int boneId, int timeaxisId) {
		this.boneId = boneId;
		this.timeaxisId = timeaxisId;
	}

	public int getBoneId() {
		return boneId;
	}

	public int getTimeaxisId() {
		return timeaxisId;
	}
}
