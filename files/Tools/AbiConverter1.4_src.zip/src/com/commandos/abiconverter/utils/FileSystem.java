package com.commandos.abiconverter.utils;

import java.io.File;

public class FileSystem {

	public static void createFolder(String foldername) {
		File folder = new File(foldername);
		if (!folder.exists()) {
			folder.mkdir();
		}
		if (!folder.isDirectory()) {
			folder.mkdir();
		}
	}
}
