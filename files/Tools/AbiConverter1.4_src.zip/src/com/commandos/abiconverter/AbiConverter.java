/*
 * ABI Converter for Commandos 2 & 3
 * by ferdinand.graf.zeppelin@gmail.com
 * v1.4 02Feb2016
 * 
 * Many thanks to NeoRAGEx2002, F.R.C, jinshengmao, URF, daoyang
 * for unveiling the ABI file format
 */

package com.commandos.abiconverter;

import java.io.*;

import com.commandos.abiconverter.entities.AbiFile;
import com.commandos.abiconverter.fileIO.AbiReader;
import com.commandos.abiconverter.fileIO.AbiWriter;
import com.commandos.abiconverter.fileIO.LittleEndianDataInputStream;
import com.commandos.abiconverter.fileIO.ObjWriter;
import com.commandos.abiconverter.fileIO.XmlWriter;
import com.commandos.abiconverter.utils.Constants;

public class AbiConverter {

	private static void Usage() {
		System.err.println("Usage: java AbiConverter [-c] [-o] [-t] [-x] <ABI file>");
		System.err.println("\t\t\t-c\tConvert ABI file");
		System.err.println("\t\t\t-o\tExtract Models as OBJ");
		System.err.println("\t\t\t-t\tExtract Textures as BMP");
		System.err.println("\t\t\t-x\tExtract ABI as XML");
		System.exit(1);
	}

	public static void main(String[] args) {
		
		if (args.length < 2) {
			Usage();
		}
		
		boolean opt_c = false;
		boolean opt_o = false;
		boolean opt_t = false;
		boolean opt_x = false;
		
		for (int i = 0; i < args.length-1; i++) {
			if (args[i].length() != 2) {
				Usage();
			}
			if (args[i].charAt(0) != '-') {
				Usage();
			}
			switch (args[i].charAt(1)) {
				case 'c':
					if (opt_c) Usage();
					opt_c = true;
					break;
				case 'o':
					if (opt_o) Usage();
					opt_o = true;
					break;
				case 't':
					if (opt_t) Usage();
					opt_t = true;
					break;
				case 'x':
					if (opt_x) Usage();
					opt_x = true;
					break;
				default:
					Usage();
			}
		}
		String filename = args[args.length-1].toUpperCase();
		
		File file = new File(filename);
		if (!file.exists()) {
			System.err.println("\nFile " + filename + " not found!");
			System.exit(1);
		}
		
		
		int supportedVersions[] = {1011, 1040, 1050, 1060};
		
		filename = file.getAbsolutePath();
		
		int version = 0;
		
		try {
			
			LittleEndianDataInputStream dis = new LittleEndianDataInputStream(filename);
			
			if (!dis.readIdent().equals(Constants.ABI_IDENTIFIER)) {
				System.err.println("Not a valid ABI file!");
				dis.close();
				System.exit(1);
			}
			String v = dis.readIdent();
			version = Integer.parseInt(v);
			dis.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		boolean wrongVersion = true;
		for (int i = 0; i < supportedVersions.length; i++) {
			if (supportedVersions[i] == version) {
				wrongVersion = false;
				break;
			}
		}
		if (wrongVersion) {
			System.err.println("Unsupported LDMB version found: " + version);
			System.err.println("Supported versions are:");
			for (int i = 0; i < supportedVersions.length; i++) {
				System.err.println("    " + supportedVersions[i]);
			}
			System.exit(1);
		}
		
		AbiFile abi;
		AbiReader reader = new AbiReader();
		AbiWriter writer = new AbiWriter();
		
		try {
			
			abi = reader.readAbi(filename, false);
			
			if (opt_c) {
				if (version == 1011) {
					writer.writeAbi(abi, file, 1060);
				} else {
					writer.writeAbi(abi, file, 1011);
				}
			}
			if (opt_o) {
				ObjWriter.writeObj(abi, filename);
				opt_t = true;
			}
			if (opt_t) {
				reader.extractBitmaps(abi, filename);
			}
			if (opt_x) {
				XmlWriter.writeXml(abi, version, filename);
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
