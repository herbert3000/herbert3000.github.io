package com.commandos.abiconverter.entities;

import java.io.*;

public class Texture {
	
	private int identifier = 0; // C2
	private int width;
	private int height;
	private String name;
	private byte[] pal;
	private byte[] pix;
	private int offset;
	private int texture_id = 0; // C3
	
	public Texture(int identifier, int width, int height, String name, byte[] pal, byte[] pix, int offset) {
		this.identifier = identifier;
		this.width  = width;
		this.height = height;
		this.name = name;
		this.pal  = pal;
		this.pix  = pix;
		this.offset = offset;
	}
	
	public Texture(int width, int height, String name, byte[] pal, byte[] pix, int offset, int texture_id) {
		this.width  = width;
		this.height = height;
		this.name = name;
		this.pal  = pal;
		this.pix  = pix;
		this.offset = offset;
		this.texture_id = texture_id;
	}
	
	public int getIdentifier() {
		return identifier;
	}
	
	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}

	public String getName() {
		return name;
	}
	
	public byte[] getPal() {
		return pal;
	}
	
	public byte[] getPix() {
		return pix;
	}
	
	public int getRelativeTextureOffset() {
		return offset;
	}
	
	public int getTextureId() {
		return texture_id;
	}
	
	public void extractBitmap(String foldername) throws IOException {
		int size = width*height + 256*3;
		byte header[] = new byte[54];
		for (int i=2; i<54; i++) {
			header[i] = 0;
		}
		header[0]  = 0x42;
		header[1]  = 0x4D;
		header[2]  = (byte) (size & 0xFF);
		header[2]  = (byte) ((size >> 8) & 0xFF);
		header[4]  = (byte) ((size >> 16) & 0xFF);
		header[10] = 0x36;
		header[11] = 4;
		header[14] = 0x28;
		header[18] = (byte) (width & 0xFF);
		header[19] = (byte) ((width >> 8) & 0xFF);
		header[22] = (byte) (height & 0xFF);
		header[23] = (byte) ((height >> 8) & 0xFF);
		header[26] = 1;
		header[28] = 8;
		size = width*height;
		header[34] = (byte) (size & 0xFF);
		header[35] = (byte) ((size >> 8) & 0xFF);
		header[36] = (byte) ((size >> 16) & 0xFF);
		
		FileOutputStream fos = new FileOutputStream(new File(foldername + "\\" + name));
		BufferedOutputStream file = new BufferedOutputStream(fos);
		file.write(header);
		for (int i=0; i<256*3; i+=3) {
			file.write(pal[i+2]);
			file.write(pal[i+1]);
			file.write(pal[i]);
			file.write(0);
		}
		for (int i=height-1; i>=0; i--) {
			for (int j=0; j<width; j++) {
				file.write(pix[i*width + j]);
			}
		}
		file.close();
	}
	
}
