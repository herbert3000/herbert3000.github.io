package com.commandos.abiconverter.entities;

public class Animation {
	
	private String name;
	private int unknown;
	private int num_related_bones;
	private BoneAnimation[] bone_anim;
	
	public Animation(String name, int unknown, int num_related_bones,
			BoneAnimation[] bone_anim) {
		this.name = name;
		this.unknown = unknown;
		this.num_related_bones = num_related_bones;
		this.bone_anim = bone_anim;
	}
	
	public Animation(String name, int unknown) {
		this.name = name;
		this.unknown = unknown;
	}
	
	public void setBoneAnimation(int num_related_bones, BoneAnimation[] bone_anim) {
		this.num_related_bones = num_related_bones;
		this.bone_anim = bone_anim;
	}
	
	public String getName() {
		return name;
	}
	
	public int getUnknown() {
		return unknown;
	}
	
	public int getNumRelatedBones() {
		return num_related_bones;
	}
	
	public BoneAnimation[] getBoneAnimation() {
		return bone_anim;
	}
	
}
