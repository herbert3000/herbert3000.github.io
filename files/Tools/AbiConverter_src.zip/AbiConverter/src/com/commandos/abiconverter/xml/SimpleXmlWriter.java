package com.commandos.abiconverter.xml;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Stack;

import com.commandos.abiconverter.Constants;

public class SimpleXmlWriter implements XmlWriter {

	private static final String SPACE = "  ";

	private OutputStreamWriter xml;
	private Stack<String> nodeStack;
	private int indent;

	public SimpleXmlWriter(OutputStreamWriter xml) throws IOException {
		this.xml = xml;
		nodeStack = new Stack<String>();
		indent = 0;
		
		writeHeader();
	}

	private void writeHeader() throws IOException {
		xml.write("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
	}

	private String getIndent() {
		String s = "";
		for (int i = 0; i < indent; i++) {
			s += SPACE;
		}
		return s;
	}

	@Override
	public void createNode(String nodeName) throws IOException {
		xml.write("\r\n" + getIndent() + "<" + nodeName + ">");
		nodeStack.push(nodeName);
		indent++;
	}

	@Override
	public void createNode(String nodeName, Object value) throws IOException {
		if ((value instanceof String) == false) {
			value = new java.text.DecimalFormat(Constants.DECIMAL_FORMAT).format(value);
			value = ((String) value).replace(",", ".");
		}
		xml.write("\r\n" + getIndent() + "<" + nodeName + ">" + value + "</" + nodeName + ">");
	}

	@Override
	public void closeNode() throws IOException {
		indent--;
		xml.write("\r\n" + getIndent() + "</" + nodeStack.pop() + ">");
	}

	@Override
	public void closeNode(int count) throws IOException {
		for (int i = 0; i < count; i++) {
			indent--;
			xml.write("\r\n" + getIndent() + "</" + nodeStack.pop() + ">");
		}
	}
}
