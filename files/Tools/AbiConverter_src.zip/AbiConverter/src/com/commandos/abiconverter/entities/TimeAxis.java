package com.commandos.abiconverter.entities;

public class TimeAxis {
	
	private int numTransKf;
	private int numRotKf;
	private TransKeyframe[] transKf;
	private RotKeyframe[] rotKf;
	
	public TimeAxis(int num_translateKeyframes, TransKeyframe[] trans_keyframe,
			int num_rotateKeyframes, RotKeyframe[] rot_keyframe) {
		numTransKf = num_translateKeyframes;
		numRotKf = num_rotateKeyframes;
		transKf = trans_keyframe;
		rotKf = rot_keyframe;
	}
	
	public int getNumTransKeyframe() {
		return numTransKf;
	}
	
	public int getNumRotKeyframe() {
		return numRotKf;
	}
	
	public TransKeyframe[] getTransKeyframe() {
		return transKf;
	}
	
	public RotKeyframe[] getRotKeyframe() {
		return rotKf;
	}
	
}
