package com.commandos.abiconverter.entities;

public class Border {
	
	private int id;
	private float u;
	private float v;
	
	public Border(int id, float u_, float v_) {
		this.id = id;
		this.u = u_;
		this.v = v_;
	}
	
	public int getId() {
		return id;
	}
	
	public float getU() {
		return u;
	}
	
	public float getV() {
		return v;
	}

}
