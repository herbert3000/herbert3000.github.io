package com.commandos.abiconverter.entities;

public class TransKeyframe {
	
	private int timestamp;
	private short dx;
	private short dy;
	private short dz;
	
	public TransKeyframe(int timestamp, short dx, short dy, short dz) {
		this.timestamp = timestamp;
		this.dx = dx;
		this.dy = dy;
		this.dz = dz;
	}
	
	public void setTimestamp(int timestamp) {
		this.timestamp = timestamp;
	}
	
	public int getTimestamp() {
		return timestamp;
	}
	
	public short getDx() {
		return dx;
	}
	
	public short getDy() {
		return dy;
	}
	
	public short getDz() {
		return dz;
	}
	
}
