package com.commandos.abiconverter.fileIO;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

public class MyRandomAccessFile {

	private RandomAccessFile raf;

	public MyRandomAccessFile(String filename, String mode) throws FileNotFoundException {
		raf = new RandomAccessFile(filename, mode);
	}

	public void close() throws IOException {
		raf.close();
	}

	public int read(byte[] b) throws IOException {
		return raf.read(b);
	}

	public long getFilePointer() throws IOException {
		return raf.getFilePointer();
	}

	public void seek(long pos) throws IOException {
		raf.seek(pos);
	}

	public void skipBytes(int b) throws IOException {
		raf.skipBytes(b);
	}

	public byte readByte() throws IOException {
		return raf.readByte();
	}

	public int readUnsignedByte() throws IOException {
		return raf.readUnsignedByte();
	}

	public float readFloat() throws IOException {
		return Float.intBitsToFloat(readInt());
	}

	public int readInt() throws IOException {
		byte w[] = new byte[4];
		raf.readFully(w, 0, 4);
		return
			(w[3])		  << 24 |
			(w[2] & 0xFF) << 16 |
			(w[1] & 0xFF) <<  8 |
			(w[0] & 0xFF);
	}

	public short readShort() throws IOException {
		short s = (short) (raf.readUnsignedByte() | raf.readUnsignedByte() << 8);
		return s;
	}

	public short readSignedShort() throws IOException {
		short s = readShort();
		if (s > 32767) {
			s -= 65536;
		}
		return s;
	}

	public String readIdent() throws IOException {
		byte w[] = new byte[4];
		raf.readFully(w, 0, 4);
		return new String(w);
	}

	public String readString(int numCharacters) throws IOException {
		String s = "";
		int i;
		for (i = 0; i < numCharacters; i++) {
			char b = (char) raf.readUnsignedByte();
			if (b == 0) break;
			s += b;
		}
		raf.skipBytes(numCharacters - i - 1);
		return s;
	}
}
