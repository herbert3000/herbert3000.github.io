package com.commandos.abiconverter.xml;

import java.io.IOException;

public interface XmlWriter {
	void createNode(String nodeName) throws IOException;
	void createNode(String nodeName, Object value) throws IOException;
	void closeNode() throws IOException;
	void closeNode(int count) throws IOException;
}
