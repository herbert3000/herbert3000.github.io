package com.commandos.abiconverter.entities;

public class Polygon {
	
	private int num_borders;
	private int texture_id;
	private Border[] border;
	
	public Polygon(int num_borders, int texture_id, Border[] border) {
		this.num_borders = num_borders;
		this.texture_id = texture_id;
		this.border = border;
	}
	
	public int getNumBorders() {
		return num_borders;
	}
	
	public int getTextureId() {
		return texture_id;
	}
	
	public Border[] getBorders() {
		return border;
	}
	
	public int length() {
		return (3 + num_borders * 6);
	}
	
}
