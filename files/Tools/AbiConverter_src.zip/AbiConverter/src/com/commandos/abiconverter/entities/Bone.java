package com.commandos.abiconverter.entities;

public class Bone {
	
	private int parent;
	private float transform_x;
	private float transform_y;
	private float transform_z;
	private String name;
	private int unknown;
	
	public Bone(int parent, float x, float y, float z, String name, int unknown) {
		this.parent = parent;
		transform_x = x;
		transform_y = y;
		transform_z = z;
		this.name = name;
		this.unknown = unknown;
	}
	
	public int getParent() {
		return parent;
	}
	
	public float getTransformX() {
		return transform_x;
	}
	
	public float getTransformY() {
		return transform_y;
	}
	
	public float getTransformZ() {
		return transform_z;
	}
	
	public String getName() {
		return name;
	}
	
	public int getUnknown() {
		return unknown;
	}
	
}
