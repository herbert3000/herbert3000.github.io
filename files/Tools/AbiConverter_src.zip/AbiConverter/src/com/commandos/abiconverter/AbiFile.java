package com.commandos.abiconverter;

import java.io.*;

import com.commandos.abiconverter.entities.Animation;
import com.commandos.abiconverter.entities.Bone;
import com.commandos.abiconverter.entities.BoneAnimation;
import com.commandos.abiconverter.entities.BoneIndex;
import com.commandos.abiconverter.entities.Border;
import com.commandos.abiconverter.entities.Model;
import com.commandos.abiconverter.entities.Polygon;
import com.commandos.abiconverter.entities.RotKeyframe;
import com.commandos.abiconverter.entities.Texture;
import com.commandos.abiconverter.entities.TimeAxis;
import com.commandos.abiconverter.entities.TransKeyframe;
import com.commandos.abiconverter.entities.Vertex;
import com.commandos.abiconverter.fileIO.MyDataInputStream;
import com.commandos.abiconverter.fileIO.MyDataOutputStream;
import com.commandos.abiconverter.fileIO.MyRandomAccessFile;
import com.commandos.abiconverter.xml.SimpleXmlWriter;
import com.commandos.abiconverter.xml.XmlWriter;

public class AbiFile {

	private final int version;

	private int num_timeaxis;
	private int num_animation;
	private int num_texture;
	private int num_model;
	private int num_bone;
	private byte model_identifier = 0;
	private Texture[] texture;
	private Model[] model;
	private Bone[] bone;
	private TimeAxis[] timeaxis;
	private Animation[] animation;

	private int size_texture_header;
	private int size_bone;
	private int size_model_header;
	private int size_animation_header;
	private int size_bone_trans = 0;
	private int size_timeaxis = 0;
	private int size_texture = 0;
	private int size_model = 0;
	private int offset_animation_header;
	private int offset_bone_trans;
	private int offset_timeaxis;
	private int offset_texture;
	private int offset_model;

	private XmlWriter xmlWriter;

	public AbiFile(int version) {
		this.version = version;
	}

	private void createFolder(String foldername) {
		File folder = new File(foldername);
		if (!folder.exists()) {
			folder.mkdir();
		}
		if (!folder.isDirectory()) {
			folder.mkdir();
		}
	}

	public void extractBitmaps(String filename) throws IOException {
		String foldername = filename + Constants.FOLDER_EXTENSION;
		createFolder(foldername);
		foldername += "\\Textures";
		createFolder(foldername);
		
		for (int i=0; i<num_texture; i++) {
			texture[i].extractBitmap(foldername);
		}
	}

	public void writeXml(String filename) throws IOException {
		String foldername = filename + Constants.FOLDER_EXTENSION;
		createFolder(foldername);
		
		FileOutputStream fos = new FileOutputStream(foldername + "\\Debug.xml");
		BufferedOutputStream bos = new BufferedOutputStream(fos);
		OutputStreamWriter out = new OutputStreamWriter(bos, "UTF-8");
		switch (version) {
			case 1011:
			case 1050:
			case 1060:
				writeXml2(out);
				break;
			default:
				break;
		}
		out.close();
	}

	private void writeXml2(OutputStreamWriter xml) throws IOException {
		xmlWriter = new SimpleXmlWriter(xml);
		
		xmlWriter.createNode("LDMB");
		xmlWriter.createNode("Version", version);
		
		xmlWriter.createNode("Textures");
		for (int i = 0; i < num_texture; i++) {
			xmlWriter.createNode("Texture");
			xmlWriter.createNode("Name", texture[i].getName());
			xmlWriter.createNode("TextureId", texture[i].getTextureId());
			xmlWriter.closeNode(); // Texture
		}
		xmlWriter.closeNode(); // Textures
		
		xmlWriter.createNode("Models");
		xmlWriter.createNode("ModelFlag", model_identifier);
		for (int i=0; i<num_model; i++) {
			Model m = model[i];
			xmlWriter.createNode("Model");
			xmlWriter.createNode("Name", m.getName());
			
			xmlWriter.createNode("Vertices");
			for (int j=0; j<m.getNumVertex(); j++) {
				Vertex v = m.getVertex()[j];
				xmlWriter.createNode("Vertex");
				xmlWriter.createNode("X", v.getX());
				xmlWriter.createNode("Y", v.getY());
				xmlWriter.createNode("Z", v.getZ());
				xmlWriter.closeNode(); // Vertex
			}
			xmlWriter.closeNode(); // Vertices
			
			xmlWriter.createNode("Polygons");
			for (int j=0; j<m.getNumPolygon(); j++) {
				Polygon p = m.getPolygon()[j];
				xmlWriter.createNode("Polygon");
				xmlWriter.createNode("TextureIndex", p.getTextureId());
				xmlWriter.createNode("Vertices");
				for (int k=0; k<p.getNumBorders(); k++) {
					Border b = p.getBorders()[k];
					xmlWriter.createNode("VertexInfo");
					xmlWriter.createNode("VertexIndex", b.getId());
					xmlWriter.createNode("U", b.getU());
					xmlWriter.createNode("V", b.getV());
					xmlWriter.closeNode(); // VertexInfo
				}
				xmlWriter.closeNode(); // Vertices
				xmlWriter.closeNode(); // Polygon
			}
			xmlWriter.closeNode(); // Polygons
			
			xmlWriter.createNode("VerticesToBone");
			for (int j=0; j<num_bone; j++) {
				BoneIndex b = m.getRelatedBones()[j];
				xmlWriter.createNode("VertexIndices");
				xmlWriter.createNode("StartVertexIndex", b.getStartIndex());
				xmlWriter.createNode("EndVertexIndex", b.getEndIndex());
				xmlWriter.closeNode(); // VertexIndices
			}
			xmlWriter.closeNode(); // VerticesToBone
			
			xmlWriter.closeNode(); // Model
		}
		xmlWriter.closeNode(); // Models
		
		xmlWriter.createNode("Bones");
		for (int i=0; i<num_bone; i++) {
			Bone b = bone[i];
			xmlWriter.createNode("Bone");
			xmlWriter.createNode("ParentIndex", b.getParent());
			xmlWriter.createNode("TransformationMatrix");
			xmlWriter.createNode("X", b.getTransformX());
			xmlWriter.createNode("Y", b.getTransformY());
			xmlWriter.createNode("Z", b.getTransformZ());
			xmlWriter.closeNode(); // TransformationMatrix
			xmlWriter.createNode("Name", b.getName());
			xmlWriter.createNode("BoneUnknown", b.getUnknown());
			xmlWriter.closeNode(); // Bone
		}
		xmlWriter.closeNode(); // Bones
		
		xmlWriter.createNode("TransformationTimeAxes");
		for (int i=0; i<num_timeaxis; i++) {
			TimeAxis t = timeaxis[i];
			xmlWriter.createNode("TransformationTimeAxis");
			
			xmlWriter.createNode("TranslationKeyframes");
			for (int j=0; j<t.getNumTransKeyframe(); j++) {
				TransKeyframe tk = t.getTransKeyframe()[j];
				xmlWriter.createNode("TranslationKeyframe");
				xmlWriter.createNode("Timestamp", tk.getTimestamp());
				xmlWriter.createNode("Dx", tk.getDx() / 256.0);
				xmlWriter.createNode("Dy", tk.getDy() / 256.0);
				xmlWriter.createNode("Dz", tk.getDz() / 256.0);
				xmlWriter.closeNode(); // TranslationKeyframe
			}
			xmlWriter.closeNode(); // TranslationKeyframes
			
			xmlWriter.createNode("RotationKeyframes");
			for (int j=0; j<t.getNumRotKeyframe(); j++) {
				RotKeyframe rk = t.getRotKeyframe()[j];
				xmlWriter.createNode("RotationKeyframe");
				xmlWriter.createNode("Timestamp", rk.getTimestamp());
					xmlWriter.createNode("X", rk.getX() / 32768.0);
					xmlWriter.createNode("Y", rk.getY() / 32768.0);
					xmlWriter.createNode("Z", rk.getZ() / 32768.0);
					xmlWriter.createNode("W", rk.getW() / 32768.0);
				xmlWriter.closeNode(); // RotationKeyframe
			}
			xmlWriter.closeNode(); // RotationKeyframes
			
			xmlWriter.closeNode(); // TransformationTimeAxis
		}
		xmlWriter.closeNode(); // TransformationTimeAxes
		
		xmlWriter.createNode("Animations");
		for (int i=0; i<num_animation; i++) {
			Animation a = animation[i];
			BoneAnimation[] bone_anim = a.getBoneAnimation();
			xmlWriter.createNode("Animation");
			xmlWriter.createNode("Name", a.getName());
			xmlWriter.createNode("BoneAnimationEntries");
			for (int j=0; j<a.getNumRelatedBones(); j++) {
				xmlWriter.createNode("BoneAnimationEntry");
				xmlWriter.createNode("BoneIndex", bone_anim[j].getBoneId());
				xmlWriter.createNode("TimeAxisIndex", bone_anim[j].getTimeaxisId());
				xmlWriter.closeNode(); // BoneAnimationEntry
			}
			xmlWriter.closeNode(); // BoneAnimationEntries
			xmlWriter.closeNode(); // Animation
		}
		xmlWriter.closeNode(); // Animations
		
		xmlWriter.closeNode(); // LDMB
	}

	public void writeObj(String filename) throws IOException {
		String foldername = filename + Constants.FOLDER_EXTENSION;
		createFolder(foldername);
		foldername += "\\Models";
		createFolder(foldername);
		
		FileOutputStream fos;
		BufferedOutputStream bos;
		OutputStreamWriter out;
		
		String mtl_name = "Textures.mtl";
		fos = new FileOutputStream(new File(foldername + "\\" + mtl_name));
		bos = new BufferedOutputStream(fos);
		out = new OutputStreamWriter(bos, "UTF-8");
		
		for (int i=0; i<num_texture; i++) {
			Texture t = texture[i];
			out.write("newmtl " + i + "\r\n");
			out.write("Ka 1.000 1.000 1.000" + "\r\n");
			out.write("Kd 1.000 1.000 1.000" + "\r\n");
			out.write("illum 0" + "\r\n");
			out.write("map_Kd " + "..\\textures\\" + t.getName() + "\r\n\r\n");
		}
		out.close();
		
		for (int i=0; i<num_model; i++) {
			Model m = model[i];
			fos = new FileOutputStream(new File(foldername + "\\" + m.getName() + ".obj"));
			out = new OutputStreamWriter(fos, "UTF-8");
			
			out.write("mtllib " + mtl_name + "\r\n\r\n");
			
			for (int j=0; j<m.getNumVertex(); j++) {
				Vertex v = m.getVertex()[j];
				out.write("v " + v.toString() + "\r\n");
			}
			out.write("\r\n");
			
			for (int j=0; j<m.getNumPolygon(); j++) {
				Polygon p = m.getPolygon()[j];
				for (int k=p.getNumBorders()-1; k>=0; k--) {
					Border b = p.getBorders()[k];
					out.write("vt " + b.getU() + " " + b.getV()*-1 +"\r\n");
				}
			}
			out.write("\r\n");
			
			out.write("g " + m.getName() + "\r\n");
			
			int last_mat = -1;
			int uv_counter = 1;
			for (int j=0; j<m.getNumPolygon(); j++) {
				Polygon p = m.getPolygon()[j];
				int mat = p.getTextureId();
				if (mat != last_mat) {
					out.write("usemtl " + mat + "\r\n");
					last_mat = mat;
				}
				out.write("f");
				for (int k=p.getNumBorders()-1; k>=0; k--) {
					Border b = p.getBorders()[k];
					out.write(" " + (b.getId()+1) + "/" + (uv_counter++));
				}
				out.write("\r\n");
			}
			
			out.close();
		}
	}

	public void readAbi3(String filename) throws IOException {
		MyRandomAccessFile file = new MyRandomAccessFile(filename, "r");
		
		// LDMB Header
		file.seek(8);
		file.readShort(); // unknown
		num_timeaxis  = file.readShort();
		num_animation = file.readShort();
		num_texture   = file.readShort();
		num_model     = file.readShort();
		num_bone      = file.readShort();
		
		size_animation_header = num_animation * 0x34;
		size_texture_header   = num_texture * 0x32C;
		
		offset_texture  = file.readInt();
		offset_model    = file.readInt();
		offset_animation_header = file.readInt();
		size_bone_trans = file.readInt();
		size_timeaxis   = file.readInt();
		
		texture = new Texture[num_texture];
		for (int i=0; i<num_texture; i++) {
			int width = file.readShort();
			int height = file.readShort();
			int widthXheight = width*height;
			byte pal[] = new byte[256*3];
			byte pix[] = new byte[widthXheight];
			file.read(pal);
			String name = file.readString(32);
			if (name.length() == 0) {
				name = "Untitled-" + i + ".bmp";
			} else {
				String n = (name.substring(name.length()-4, name.length())).toLowerCase();
				if (!n.equals(".bmp")) {
					name += ".bmp";
				}
			}
			name = name.replace(" ", "_");
			
			int texture_id = file.readInt();
			int offset = file.readInt();
			int relative_texture_offset = offset - offset_texture;
			
			long pos = file.getFilePointer();
			file.seek(offset);
			file.read(pix);
			file.seek(pos);
			
			texture[i] = new Texture(width, height, name, pal, pix, relative_texture_offset, texture_id);
		}
		
		bone = new Bone[num_bone];
		for (int i=0; i<num_bone; i++) {
			int parent = file.readInt();
			int unknown = file.readInt();
			float transform_x = file.readFloat();
			float transform_y = file.readFloat();
			float transform_z = file.readFloat();
			String name = file.readString(32);
			
			bone[i] = new Bone(parent, transform_x, transform_y, transform_z, name, unknown);
		}
		
		model = new Model[num_model];
		for (int i=0; i<num_model; i++) {
			short num_vertex      = file.readShort();
			short num_polygon     = file.readShort();
			short sum_num_borders = file.readShort();
			String name = file.readString(32);
			int offset = file.readInt();
			int relative_model_offset = offset - offset_model;
			
			long pos = file.getFilePointer();
			file.seek(offset);
			
			Vertex[] vertex = new Vertex[num_vertex];
			for (int j=0; j<num_vertex; j++) {
				float x = file.readFloat();
				float y = file.readFloat();
				float z = file.readFloat();
				
				vertex[j] = new Vertex(x, y, z);
			}
			
			Polygon[] polygon = new Polygon[num_polygon];
			for (int j=0; j<num_polygon; j++) {
				int num_borders = file.readUnsignedByte();
				short texture_id = file.readShort();
				
				Border border[] = new Border[num_borders];
				for (int k=0; k<num_borders; k++) {
					int id  = file.readShort();
					float u = (float) (file.readSignedShort() / 4096.0);
					float v = (float) (file.readSignedShort() / 4096.0);
					
					border[k] = new Border(id, u, v);
				}
				
				polygon[j] = new Polygon(num_borders, texture_id, border);
			}
			
			BoneIndex[] related_bones = new BoneIndex[num_bone];
			for (int j=0; j<num_bone; j++) {
				int startIndex = file.readInt();
				int endIndex   = file.readInt();
				
				related_bones[j] = new BoneIndex(startIndex, endIndex);
			}
			
			file.seek(pos);
			
			model[i] = new Model(num_vertex, num_polygon, name, vertex, polygon, related_bones, relative_model_offset, sum_num_borders);
		}
		
		animation = new Animation[num_animation];
		for (int i=0; i<num_animation; i++) {
			String name = file.readString(32);
			int unknown = file.readInt();
			file.skipBytes(16); // unknown, always 0
			
			animation[i] = new Animation(name, unknown);
		}
		
		for (int i=0; i<num_animation; i++) {
			int num_related_bones = file.readInt();
			
			BoneAnimation[] bone_anim = new BoneAnimation[num_related_bones];
			for (int j=0; j<num_related_bones; j++) {
				int bone_id     = file.readInt();
				int timeaxis_id = file.readInt();
				
				bone_anim[j] = new BoneAnimation(bone_id, timeaxis_id);
			}
			
			animation[i].setBoneAnimation(num_related_bones, bone_anim);
		}
		
		timeaxis = new TimeAxis[num_timeaxis];
		for (int i=0; i<num_timeaxis; i++) {
			int num_translateKeyframes = file.readUnsignedByte();
			int num_rotateKeyframes = file.readUnsignedByte();
			
			TransKeyframe[] trans_keyframe = new TransKeyframe[num_translateKeyframes];
			for (int j=0; j<num_translateKeyframes; j++) {
				short dx = file.readSignedShort();
				short dy = file.readSignedShort();
				short dz = file.readSignedShort();
				trans_keyframe[j] = new TransKeyframe(0, dx, dy, dz);
			}
			for (int j=0; j<num_translateKeyframes; j++) {
				int timestamp = file.readUnsignedByte();
				trans_keyframe[j].setTimestamp(timestamp);
			}
			
			RotKeyframe[] rot_keyframe = new RotKeyframe[num_rotateKeyframes];
			for (int j=0; j<num_rotateKeyframes; j++) {
				byte rx = file.readByte();
				byte ry = file.readByte();
				byte rz = file.readByte();
				rot_keyframe[j] = new RotKeyframe(rx, ry, rz);
			}
			for (int j=0; j<num_rotateKeyframes; j++) {
				int timestamp = file.readUnsignedByte();
				rot_keyframe[j].setTimestamp(timestamp);
			}
			
			if (num_translateKeyframes % 2 != 0) {
				file.skipBytes(1); // unknown, always 0x64
			}
			
			timeaxis[i] = new TimeAxis(num_translateKeyframes, trans_keyframe, num_rotateKeyframes, rot_keyframe);
		}
		
		file.close();
	}

	public void readAbi2(String filename, boolean polygons_to_triangles) throws IOException {
		MyDataInputStream file = new MyDataInputStream(filename);
		
		// LDMB Header
		file.skipBytes(8);
		
		num_timeaxis  = file.readInt();
		num_animation = file.readInt();
		num_texture   = file.readInt();
		
		size_animation_header = num_animation * 0x34;
		size_texture_header   = num_texture * 0x32C;
		
		texture = new Texture[num_texture];
		for (int i=0; i<num_texture; i++) {
			
			int identifier = file.readInt();
			int width = file.readInt();
			int height = file.readInt();
			int widthXheight = width*height;
			String name = file.readString(32);
			if (name.length() == 0) {
				name = "Untitled-" + i + ".bmp";
			} else {
				String n = (name.substring(name.length()-4, name.length())).toLowerCase();
				if (!n.equals(".bmp")) {
					name += ".bmp";
				}
			}
			name = name.replace(" ", "_");
			
			byte pal[] = new byte[256*3];
			byte pix[] = new byte[widthXheight];
			file.read(pal);
			file.read(pix);
			
			int relative_texture_offset = size_texture;
			texture[i] = new Texture(identifier, width, height, name, pal, pix, relative_texture_offset);
			
			size_texture += widthXheight;
		}
		
		if (version == 1060) {
			model_identifier = file.readByte();
		}
		num_model = file.readInt();
		num_bone  = file.readInt();
		
		size_model_header = num_model * 0x2A;
		size_bone = num_bone * 0x34;
		
		model = new Model[num_model];
		for (int i=0; i<num_model; i++) {
			int num_vertex  = file.readInt();
			int num_polygon = file.readInt();
			String name     = file.readString(32);
			int sum_num_borders = 0;
			
			Vertex[] vertex = new Vertex[num_vertex];
			for (int j=0; j<num_vertex; j++) {
				float x = file.readFloat();
				float y = file.readFloat();
				float z = file.readFloat();
				
				vertex[j] = new Vertex(x, y, z);
			}
			
			int num_triangles = 0;
			
			Polygon[] polygon;
			Polygon[] polygon_temp = new Polygon[num_polygon];
			
			for (int j=0; j<num_polygon; j++) {
				int num_borders;
				int texture_id;
				
				if (version == 1040) {
					num_borders = file.readInt();
					texture_id  = file.readInt();
				} else { // version == 1050 || version == 1060
					num_borders = file.readUnsignedByte();
					texture_id  = file.readUnsignedByte();
				}
				sum_num_borders += num_borders;
				num_triangles += num_borders - 2;
				
				Border border[] = new Border[num_borders];
				
				for (int k=0; k<num_borders; k++) {
					int id;
					float u, v;
					if (version == 1040) {
						id = file.readInt();
						u  = file.readFloat();
						v  = file.readFloat();
					} else { // version == 1050 || version == 1060
						id = file.readSignedShort();
						u  = (float) (file.readSignedShort() / 4096.0);
						v  = (float) (file.readSignedShort() / 4096.0);
					}
					border[k] = new Border(id, u, v);
				}
				
				polygon_temp[j] = new Polygon(num_borders, texture_id, border);
			}
			
			if (!polygons_to_triangles) {
				
				polygon = polygon_temp;
				
			} else {
				
				polygon = new Polygon[num_triangles];
				
				int t = 0; // triangle counter
				for (int j=0; j<num_polygon; j++) {
					Polygon p = polygon_temp[j];
					Border[] b = p.getBorders();
					int num_b = p.getNumBorders()-2;
					int texId = p.getTextureId();
					
					for (int k=0; k<num_b; k++) {
						Border[] border = new Border[3];
						
						border[0] = new Border(
							b[0].getId(),
							b[0].getU(),
							b[0].getV());
							
						border[1] = new Border(
							b[k+1].getId(),
							b[k+1].getU(),
							b[k+1].getV());
						
						border[2] = new Border(
							b[k+2].getId(),
							b[k+2].getU(),
							b[k+2].getV());
						
						polygon[t++] = new Polygon(3, texId, border);
					}
				}
				
				num_polygon = num_triangles;
				sum_num_borders = num_triangles * 3;
			}
			
			BoneIndex[] related_bones = new BoneIndex[num_bone];
			for (int j=0; j<num_bone; j++) {
				int startIndex = file.readInt();
				int endIndex   = file.readInt();
				
				related_bones[j] = new BoneIndex(startIndex, endIndex);
			}
			
			int relative_model_offset = size_model;
			model[i] = new Model(num_vertex, num_polygon, name, vertex, polygon, related_bones, relative_model_offset, sum_num_borders);
			
			size_model += (num_bone * 8) + model[i].length();
		}
		
		bone = new Bone[num_bone];
		for (int i=0; i<num_bone; i++) {
			int parent = file.readInt();
			float transform_x = file.readFloat();
			float transform_y = file.readFloat();
			float transform_z = file.readFloat();
			String name = file.readString(32);
			int unknown = file.readInt();
			
			bone[i] = new Bone(parent, transform_x, transform_y, transform_z, name, unknown);
		}
		
		timeaxis = new TimeAxis[num_timeaxis];
		for (int i=0; i<num_timeaxis; i++) {
			int num_translateKeyframes = file.readInt();
			
			TransKeyframe[] trans_keyframe = new TransKeyframe[num_translateKeyframes];
			for (int j=0; j<num_translateKeyframes; j++) {
				int timestamp = file.readUnsignedByte();
				short dx = file.readSignedShort();
				short dy = file.readSignedShort();
				short dz = file.readSignedShort();
				
				trans_keyframe[j] = new TransKeyframe(timestamp, dx, dy, dz);
			}
			
			int num_rotateKeyframes = file.readInt();
			RotKeyframe[] rot_keyframe = new RotKeyframe[num_rotateKeyframes];
			for (int j=0; j<num_rotateKeyframes; j++) {
				int timestamp = file.readUnsignedByte();
				short x = file.readSignedShort();
				short y = file.readSignedShort();
				short z = file.readSignedShort();
				short w = file.readSignedShort();
				
				rot_keyframe[j] = new RotKeyframe(timestamp, x, y, z, w);
			}
			
			timeaxis[i] = new TimeAxis(num_translateKeyframes, trans_keyframe, num_rotateKeyframes, rot_keyframe);
			
			size_timeaxis += (2 + num_translateKeyframes * 7 + num_rotateKeyframes * 4);
			if (num_translateKeyframes % 2 != 0) {
				size_timeaxis++;
			}
		}
		
		// only in 1050 and 1060
		// 1040 has different (unknown) format
		animation = new Animation[num_animation];
		for (int i=0; i<num_animation; i++) {
			String name = file.readString(32);
			int unknown = file.readInt(); // unknown
			file.readString(0x18); // UNKNOWN
			int num_related_bones = file.readInt();
			
			BoneAnimation[] bone_anim = new BoneAnimation[num_related_bones];
			for (int j=0; j<num_related_bones; j++) {
				int bone_id     = file.readInt();
				int timeaxis_id = file.readInt();
				
				bone_anim[j] = new BoneAnimation(bone_id, timeaxis_id);
			}
			
			animation[i] = new Animation(name, unknown, num_related_bones, bone_anim);
			
			size_bone_trans += (4 + num_related_bones * 8);
		}
		
		offset_animation_header = Constants.SIZE_ABI_HEADER + size_texture_header + size_bone + size_model_header;
		offset_bone_trans       = offset_animation_header + size_animation_header;
		offset_timeaxis         = offset_bone_trans + size_bone_trans;
		offset_texture          = offset_timeaxis + size_timeaxis;
		offset_model            = offset_texture + size_texture ;
		
		file.close();
	}

	public void writeAbi3(File f) throws IOException {
		String filename = f.getAbsolutePath();
		String foldername = filename + Constants.FOLDER_EXTENSION;
		createFolder(foldername);
		
		MyDataOutputStream file = new MyDataOutputStream(foldername + "\\" + f.getName());
		
		// ABI Header
	    file.writeBytes("LDMB");
	    file.writeBytes("1011");
	    file.writeShort(0);
		
		file.writeShort(num_timeaxis);
		file.writeShort(num_animation);
		file.writeShort(num_texture);
		file.writeShort(num_model);
		file.writeShort(num_bone);
		
		file.writeInt(offset_texture);
		file.writeInt(offset_model);
		file.writeInt(offset_animation_header);
		file.writeInt(size_bone_trans);
		file.writeInt(size_timeaxis);
		
		// Texture Header
		for (int i=0; i<num_texture; i++) {
			Texture t = texture[i];
			file.writeShort(t.getWidth());
			file.writeShort(t.getHeight());
			file.write(t.getPal());
			file.writeString(t.getName(), 32);
			int texId = t.getTextureId();
			if (texId == 0) {
				texId = (int) Math.abs(Math.random()*0x7F000000 + 0xFFFFFF);
			}
			file.writeInt(texId);
			file.writeInt(offset_texture + t.getRelativeTextureOffset());
		}
		
		// Bones
		for (int i=0; i<num_bone; i++) {
			Bone b = bone[i];
			file.writeInt(b.getParent());
			file.writeInt(b.getUnknown()); // UNKNWON BONE00
			file.writeFloat(b.getTransformX());
			file.writeFloat(b.getTransformY());
			file.writeFloat(b.getTransformZ());
			file.writeString(b.getName(), 32);
		}
		
		// Model Header
		for (int i=0; i<num_model; i++) {
			Model m = model[i];
			file.writeShort(m.getNumVertex());
			file.writeShort(m.getNumPolygon());
			file.writeShort(m.getSumNumBorders());
			file.writeString(m.getName(), 32);
			file.writeInt(offset_model + m.getRelativeModelOffset());
		}
		
		// Animation Header
		for (int i=0; i<num_animation; i++) {
			Animation a = animation[i];
			file.writeString(a.getName(), 32);
			file.writeInt(a.getUnknown()); // unknown
			file.writeInt(0); // unknown, always 0
			file.writeInt(0); // unknown, always 0
			file.writeInt(0); // unknown, always 0
			file.writeInt(0); // unknown, always 0
		}
		
		// Bone Transformations
		for (int i=0; i<num_animation; i++) {
			Animation a = animation[i];
			file.writeInt(a.getNumRelatedBones());
			for (int j=0; j<a.getNumRelatedBones(); j++) {
				BoneAnimation b = a.getBoneAnimation()[j];
				file.writeInt(b.getBoneId());
				file.writeInt(b.getTimeaxisId());
			}
		}
		
		// TimeAxis
		for (int i=0; i<num_timeaxis; i++) {
			TimeAxis t = timeaxis[i];
			int numTransKf = t.getNumTransKeyframe();
			int numRotKf = t.getNumRotKeyframe();
			
			file.writeByte(numTransKf);
			file.writeByte(numRotKf);
			
			for (int j=0; j<numTransKf; j++) {
				TransKeyframe tk = t.getTransKeyframe()[j];
				file.writeSignedShort(tk.getDx());
				file.writeSignedShort(tk.getDy());
				file.writeSignedShort(tk.getDz());
			}
			
			for (int j=0; j<numTransKf; j++) {
				TransKeyframe tk = t.getTransKeyframe()[j];
				file.writeByte(tk.getTimestamp());
			}
			
			for (int j=0; j<numRotKf; j++) {
				RotKeyframe rk = t.getRotKeyframe()[j];
				file.writeByte((byte) (rk.getX() / 256.0));
				file.writeByte((byte) (rk.getY() / 256.0));
				file.writeByte((byte) (rk.getZ() / 256.0));
			}
			
			for (int j=0; j<numRotKf; j++) {
				RotKeyframe rk = t.getRotKeyframe()[j];
				file.writeByte(rk.getTimestamp());
			}
			
			if (numTransKf % 2 != 0) {
				file.writeByte(0x64);
			}
		}
		
		// Texture
		for (int i=0; i<num_texture; i++) {
			file.write(texture[i].getPix());
		}
		
		// Model
		for (int i=0; i<num_model; i++) {
			Model m = model[i];
			int num_vertex = m.getNumVertex();
			int num_polygon = m.getNumPolygon();
			
			for (int j=0; j<num_vertex; j++) {
				Vertex v = m.getVertex()[j];
				file.writeFloat(v.getX());
				file.writeFloat(v.getY());
				file.writeFloat(v.getZ());
			}
			
			for (int j=0; j<num_polygon; j++) {
				Polygon p = m.getPolygon()[j];
				int num_borders = p.getNumBorders();
				int texture_id = p.getTextureId();
				
				file.writeByte(num_borders);
				file.writeShort(texture_id);
				
				for (int k=0; k<num_borders; k++) {
					Border b = p.getBorders()[k];
					file.writeShort(b.getId());
					file.writeShort((short)(b.getU() * 4096));
					file.writeShort((short)(b.getV() * 4096));
				}
			}
			
			for (int j=0; j<num_bone; j++) {
				BoneIndex b = m.getRelatedBones()[j];
				file.writeInt(b.getStartIndex());
				file.writeInt(b.getEndIndex());
			}
		}
		
		file.close();
	}

	public void writeAbi2(String filename) {
		/* TODO */
	}
}
