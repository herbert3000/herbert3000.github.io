package com.commandos.abiconverter;

public class Constants {

	public static final String DECIMAL_FORMAT = "#.####";
	public static final String FOLDER_EXTENSION = ".files";
	
	public static final int SIZE_ABI_HEADER = 0x28;
	
}
