package com.commandos.abiconverter.entities;

public class Model {
	
	private int num_vertex;
	private int num_polygon;
	private String name;
	private Vertex[] vertex;
	private Polygon[] polygon;
	private BoneIndex[] relatedBones;
	private int offset;
	private int sum_num_borders;
	
	public Model(int num_vertex, int num_polygon, String name, Vertex[] vertex, Polygon[] polygon, BoneIndex[] b, int offset, int sum_num_borders) {
		this.num_vertex = num_vertex;
		this.num_polygon = num_polygon;
		this.name = name;
		this.vertex = vertex;
		this.polygon = polygon;
		this.relatedBones = b;
		this.offset = offset;
		this.sum_num_borders = sum_num_borders;
	}
	
	public int getNumVertex() {
		return num_vertex;
	}
	
	public int getNumPolygon() {
		return num_polygon;
	}
	
	public String getName() {
		return name;
	}
	
	public Vertex[] getVertex() {
		return vertex;
	}
	
	public Polygon[] getPolygon() {
		return polygon;
	}
	
	public BoneIndex[] getRelatedBones() {
		return relatedBones;
	}
	
	public int getRelativeModelOffset() {
		return offset;
	}
	
	public int length() {
		int len = num_vertex * 12;
		for (int i=0; i<num_polygon; i++) {
		  len += polygon[i].length();
		}
		return len;
	}
	
	public int getSumNumBorders() {
		return sum_num_borders;
	}
	
}
