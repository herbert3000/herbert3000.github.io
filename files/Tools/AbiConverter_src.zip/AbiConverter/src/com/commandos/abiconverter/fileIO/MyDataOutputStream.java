package com.commandos.abiconverter.fileIO;

import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class MyDataOutputStream {

	private DataOutputStream dos;

	public MyDataOutputStream(String filename) throws FileNotFoundException {
		 dos =
		    new DataOutputStream(
		    new BufferedOutputStream(
		    new FileOutputStream(filename)
		 ));
	}

	public void close() throws IOException {
		dos.close();
	}

	public void writeFloat(float f) throws IOException {
		int bits = Float.floatToIntBits(f);
		dos.writeByte((byte)(bits & 0xFF));
		dos.writeByte((byte)((bits >> 8) & 0xFF));
		dos.writeByte((byte)((bits >> 16) & 0xFF));
		dos.writeByte((byte)((bits >> 24) & 0xFF));
	}

	public void writeInt(int i) throws IOException {
		int o = 
			(i & 0xFF000000) >> 24 |
			(i & 0x00FF0000) >>  8 |
			(i & 0x0000FF00) <<  8 |
			(i & 0x000000FF) << 24;
		dos.writeInt(o);
	}

	public void writeShort(int i) throws IOException {
		int o = 
			(i & 0xFF00) >> 8 |
			(i & 0x00FF) << 8;
		dos.writeShort(o);
	}

	public void writeSignedShort(int i) throws IOException {
		int o = 
			(i & 0xFF00) >> 8 |
			(i & 0x00FF) << 8;
		if (o > 32767) {
			o -= 65536;
		}
		dos.writeShort(o);
	}

	public void writeString(String s, int l) throws IOException {
		byte b[] = new byte[l];
		System.arraycopy(s.getBytes(), 0, b, 0, s.length());
		dos.write(b);
	}

	public void writeBytes(String string) throws IOException {
		dos.writeBytes(string);
	}

	public void writeByte(int b) throws IOException {
		dos.writeByte(b);
	}

	public void write(byte[] b) throws IOException {
		dos.write(b);
	}
}
