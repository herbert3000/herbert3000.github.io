package com.commandos.abiconverter.entities;

public class BoneAnimation {
	
	private int bone_id;
	private int timeaxis_id;
	
	public BoneAnimation(int bone_id, int timeaxis_id) {
		this.bone_id = bone_id;
		this.timeaxis_id = timeaxis_id;
	}
	
	public int getBoneId() {
		return bone_id;
	}
	
	public int getTimeaxisId() {
		return timeaxis_id;
	}
	
}
