=== RlcTools v2.0 ===
With these tools you can extract and repack the file DATA\WOFIP\tst.arlc in which the images of the Commandos 2 main menu are stored.


=== Usage ===
java RlcEx tst.arlc
This will extract the content of the file tst.arlc into the folder tst.arlc.files

java RlcImp tst.arlc.files
This will create the file tst.arlc by reading the files inside the folder tst.arlc.files


=== Requirements ===
Java Runtime Environment (JRE)
An image manipulation program other than MS Paint
and of course Commandos 2


=== Important notes ===
All bitmaps must be 16bit-BMPs (R5 G6 B5)!
If you use the standard Microsoft 24bit-BMPs, the output will be useless.

In GIMP for example you can create a 16bit-BMP this way:
In the "Save as BMP" dialog
expand "Advanced Options" and
select "16 bits  R5 G6 B5"


Please don't hesitate to contact me if you encounter any problems:
ferdinand.graf.zeppelin@gmail.com