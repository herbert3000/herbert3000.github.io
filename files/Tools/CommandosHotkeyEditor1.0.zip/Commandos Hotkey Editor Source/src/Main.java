import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

public class Main {
	
	private static RandomAccessFile file;
	
	public static void main(String[] args) {
		if (args.length == 0) {
			System.err.println("No argument specified!");
			System.exit(1);
		}
		String exePath = args[0];
		File exeFile = new File(exePath);
		checkFile(exeFile);
		
		File hotkeyFile = new File("Hotkeys.txt");
		File offsetFile = new File("Offsets.txt");
		checkFile(hotkeyFile);
		checkFile(offsetFile);
		
		try {
			TextFileReader reader = new TextFileReader();
			HashMap<String, Integer> hotkeys = reader.readFile(hotkeyFile);
			HashMap<String, Integer> offsets = reader.readFile(offsetFile);
			
			file = new RandomAccessFile(exeFile, "rw");
			
			Iterator<Entry<String, Integer>> it = hotkeys.entrySet().iterator();
		    while (it.hasNext()) {
		    	Entry<String, Integer> pair = it.next();
		        String key = pair.getKey();
		        int value = pair.getValue();
		        
		        if (offsets.containsKey(key)) {
		        	int address = offsets.get(key);
		        	file.seek(address);
		        	file.writeByte(value);
		        } else {
		        	System.out.println("No address found for hotkey " + pair.getKey());
		        }
		        it.remove();
		    }
			
		} catch (IOException e) {
			System.err.println("An error occured: " + e.getMessage());
			System.exit(1);
		}
		System.out.println("Done!");
	}

	private static void checkFile(File file) {
		if (!file.exists()) {
			System.err.println("File " + file.getName() + " not found!");
			System.exit(1);
		}
	}
}
