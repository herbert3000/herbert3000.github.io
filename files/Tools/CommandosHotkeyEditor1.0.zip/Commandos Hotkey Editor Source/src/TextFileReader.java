import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.StringTokenizer;

public class TextFileReader {

	public HashMap<String, Integer> readFile(File file) throws IOException {
		HashMap<String, Integer> map = new HashMap<String, Integer>();
		
		FileReader input = new FileReader(file);
		BufferedReader buf = new BufferedReader(input);
		String line = null;
		
		while ((line = buf.readLine()) != null) {
			if (line.length() == 0) continue;
			
			int pos = line.indexOf("//");
			if (pos != -1) {
				line = line.substring(0, pos);
				if (line.length() == 0) continue;
			}
			
			StringTokenizer st = new StringTokenizer(line, "\t ");
			
			if (st.hasMoreElements()) {
				String key = st.nextToken();
				if (st.hasMoreElements()) {
					String str = st.nextToken();
					int value;
					if (str.length() == 1) {
						value = (int) str.charAt(0);
					} else {
						value = Integer.parseInt(str, 16);  
					}
					map.put(key, value);
				}
			}
		}
		buf.close();
		
		return map;
	}
}
