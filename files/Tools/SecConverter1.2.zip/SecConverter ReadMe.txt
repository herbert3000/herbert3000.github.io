Commandos SEC Converter
======================= v1.2 beta

Drag any C:BEL *.SEC file on the 
executable to convert it to the C2 format.

The generated file can now be opened with the 
SECEditor.exe from the Commandos Developing Toolkit.




ferdinand.graf.zeppelin@gmail.com
18/01/09

