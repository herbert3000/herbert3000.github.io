MultiExtractor


for
	Commandos: Behind Enemy Lines
	Commandos: Beyond the Call of Duty
	Commandos II: Men of Courage


Usage:

	Drag'n'Drop the files onto the application

	or use the command prompt:
	MultiExtractor <filename> [<filename> ...]
	

Supported file types (C1):

	WAD->BMP
	RLE->BMP
	RLC->BMP
	ZOM->BMP
	FNT->BMP
	SEC->SEC*
	ANM->ANM*

	*BCD format->BEL format


Supported file types (C2):

	FNC->BMP
	FNM->BMP


-----
by ferdinand.graf.zeppelin@gmail.com


20.04.2012_b4