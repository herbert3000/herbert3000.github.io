 Commandos - WAD Creator
-------------------------

This program repacks extracted "Commandos: Behind Enemy Lines" *.WAD archives.

Run it with the following java command:
 >java WadCreator

The program will ask you for a directory.
Type in the directory in which you stored the images.

All images have to be 256-Colors-Bitmaps with the extension .BMP,
24-Bit-Bitmaps, 16-Colors-Bitmaps and Monochrome-Bitmaps are not supported.

To add IMAGE01.RLE to the archive, you have to store
 - IMAGE01.BMP
 - IMAGE01_MASK.BMP
in the same directory. The extension *.RLE is not allowed!
Mask colors: black = transparent, white = solid, anything else = semi-transparent.
Please make sure, that black has the RGB values 0 0 0 and white 255 255 255.

Don't forget to back up the original files.

Please contact me, if the program reports any errors
or when the game crashes with the new WAD archive.


Java Runtime Environment required. (sun.com)
No warranty, all rights reserved.
� 2009 Ferdinand.Graf.Zeppelin@gmail.com
"Commandos: Behind Enemy Lines" is a trademark of Eidos Interactive Ltd


v1.3/090409