Just released some unfinished tools.

CaraCreator looks fine but there are still some problems.

VOL Reader will not be released when it's finished (will be part of VOL Creator).

VOL Creator will be some kind of a (basic) map editor.