public class wad_rle {

	public String name;
	public int width;
	public int height;
	public int data[][];

	public wad_rle(String name, int width, int height, int data[][]) {
		this.name   = name;
		this.width  = width;
		this.height = height;
		this.data   = data;
	}

	public String getName() {
		return name;
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}

	public int[][] getData() {
		return data;
	}

}