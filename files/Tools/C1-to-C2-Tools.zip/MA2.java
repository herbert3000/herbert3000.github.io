// COMMANDOS BEL TOOL
/*
    INPUT:   BEL VOL + WAD
    OUTPUT:  MA2 Descripition File + Sprites
    USAGE:   java MA2 <file.VOL> <file.WAD> [angle scale]
					angle: int   (default: 40)
					scale: float (default: 1.0)
    
	NOTE:    Distribute MA2.class together with wad_rle.class
*/

import java.io.*;
import java.util.*;

public class MA2 {

  public static int readUnsignedInt(DataInputStream in) throws IOException {
    return (in.readUnsignedByte() | in.readUnsignedByte() << 8 |
	        in.readUnsignedByte() << 16 | in.readUnsignedByte() << 24); 
  }
  
  public static void main (String [] args) {
  
    float scale = 1.0f;
    boolean fos1_created = false;
	boolean fos2_created = false;
	String vol_filename  = "<not yet set>";
	String wad_filename  = "<not yet set>";
	String line = ""; // current line in VOL file
	int z = 0; // index of current line in VOL file
	int angle = 40; // map angle - Commandos standard = 40�, SketchUp ISO = 35�, Real ISO = 30�

    try {
	
	  System.out.print("\n "+(char)201);
	  for (int i=0;i<27;i++) System.out.print((char)205);
	  System.out.println((char)187);
	  System.out.println(" "+(char)186+" Commandos - MA2 Generator "+(char)186);
	  System.out.print(" "+(char)200);
	  for (int i=0;i<27;i++) System.out.print((char)205);
	  System.out.println((char)188);
	
	  // get VOL and WAD filename (as arguments or from console)
	  Scanner scan = new Scanner(System.in);
	  if (args.length<2) {
	    System.out.print("\nVOL>");
	    vol_filename = scan.next().toUpperCase();
		System.out.print("\nWAD>");
	    wad_filename = scan.next().toUpperCase();
	  } else {
	    vol_filename = args[0].toUpperCase();
		wad_filename = args[1].toUpperCase();
		if (args.length>2) {
		  angle = Integer.parseInt(args[2]);
		  if (args.length>3) {
		    scale = Float.parseFloat(args[3]);
		  }
		}
	  }
	  
	  // check if files exist
	  File vol_file = new File(vol_filename);
	  File wad_file = new File(wad_filename);
	  if (!vol_file.exists()) {
	    System.out.println("\nFile "+vol_filename+" doesn't exist!");
		System.exit(1);
	  }
	  if (!wad_file.exists()) {
	    System.out.println("\nFile "+wad_filename+" doesn't exist!");
		System.exit(1);
	  }
	  
	  vol_filename = vol_file.getAbsolutePath();
	  wad_filename = wad_file.getAbsolutePath();
	  
	  int tmp; // temp variable

	  // read WAD
	  System.out.print("\nReading WAD...");
	  
	  DataInputStream dis = new DataInputStream(new FileInputStream(wad_filename));
	  dis.skipBytes(400); // skip unknown WAD header
	  
	  tmp = readUnsignedInt(dis); // read number of color palettes
	  dis.skipBytes(tmp*525); // skip all color palettes
	  
	  int nbrOfPictures = readUnsignedInt(dis);
	  boolean wad_isRle[] = new boolean[nbrOfPictures];
	  wad_rle rles[] = new wad_rle[nbrOfPictures]; // > class wad_rle
	  
	  // read pictures
	  for (int i=0;i<nbrOfPictures;i++) {
	  
	    // read name
		String name = "";
		while ((tmp=dis.readUnsignedByte())!=0) {
		  name+=(char)tmp;
		}
		dis.skipBytes(31-name.length()); // skip 0's after name
		
		// check if picture is BMP or RLE
		if (name.charAt(name.length()-3)=='R') {
		  wad_isRle[i] = true;
		} else {
		  wad_isRle[i] = false;
		}
		
	    if (!wad_isRle[i]) { // BMP
		
		  // skip header, pixel data and palette ID
		  tmp = readUnsignedInt(dis);
		  dis.skipBytes(28+tmp+4);
		
		} else { // RLE
		
		  // read header
		  dis.skipBytes(16);
		  int height = readUnsignedInt(dis);
		  int width  = readUnsignedInt(dis);
		  dis.skipBytes(8);
		  
		  int wad_sprite[][] = new int[height][width];
		  
		  // read pixel data
		  for (int j=0;j<height;j++) {
		    int pos = 0; // position in current pixel line
			
		    while (pos!=width) {
		      int in = dis.readUnsignedByte();
			  
			  if (in == 255) { // transparent pixels
			    in = dis.readUnsignedByte();
			    for (int k=0;k<in;k++) {
			       wad_sprite[j][k+pos] = 0; // fill with black pixels
			    }
			    pos+=in;
			  } else if (in == 254) { // semi-transparent pixels
			    in = dis.readUnsignedByte();
			    for (int k=0;k<in;k++) {
			       wad_sprite[j][k+pos] = 127; // fill with gray pixels
			    }
				dis.skipBytes(in);
			    pos+=in;
			  } else { // opaque pixels
			    for (int k=0;k<in;k++) {
			       wad_sprite[j][k+pos] = 255; // fill with white pixels
			    }
				dis.skipBytes(in);
			    pos+=in;
			  }
			}
		  }
		  
		  // skip line offset table and color palette ID
		  tmp = readUnsignedInt(dis);
		  dis.skipBytes(tmp+4);
		  
		  // create object wad_rle
		  rles[i] = new wad_rle(name,width,height,wad_sprite);
		  // wad_rle methods: getName(), getWidth(), getHeight(), getData()
		  
		} 
	  }
	  
	  dis.close();
	  // reading WAD completed!
	  
	  // read VOL
	  System.out.print("done!\nReading VOL...");
	  
	  // create output directory
	  File dir = new File(vol_filename.substring(0,vol_filename.length()-4)+".MA2.xfiles");
	  dir.mkdir();
	  
	  // create temporary files
	  BufferedWriter fos1 = new BufferedWriter(new FileWriter(vol_filename+"_ObjectInfo.tmp"));
	  fos1_created = true;
	  BufferedWriter fos2 = new BufferedWriter(new FileWriter(vol_filename+"_RenderInfo.tmp"));
	  fos2_created = true;
	  
	  // write xml header
	  fos1.write("<?xml version=\"1.0\" encoding=\"utf-16\"?>\n");
	  //fos1.write("<MA2 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">\n");
	  fos1.write("<MA2>\n");
      fos1.write("  <VersionSign>Comm2</VersionSign>\n");
      //fos1.write("  <Unknown>AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==</Unknown>\n");
	  fos1.write("  <Unknown>00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00</Unknown>\n");
      fos1.write("  <ViewInfo>\n");
      fos1.write("    <ViewInfoBlock>\n");
      fos1.write("      <OffsetX>0</OffsetX>\n");
      fos1.write("      <OffsetY>0</OffsetY>\n");
      fos1.write("      <ViewLongitude>0</ViewLongitude>\n");
      fos1.write("      <ViewLatitude>"+angle+"</ViewLatitude>\n");
      //fos1.write("      <Unknown1>0</Unknown1>\n");
      //fos1.write("      <Unknown4>0</Unknown4>\n");
      fos1.write("    </ViewInfoBlock>\n");
      fos1.write("  </ViewInfo>\n");
	  fos1.write("  <ObjectInfo>\n");
	  
	  fos2.write("  <RenderInfo>\n");
	  fos2.write("    <ArrayOfRenderInfoBlock>\n");
	  
	  char c;
	  int counter = 0; // ObjectIndex counter
	  int tile_counter = 0;
      BufferedReader f = new BufferedReader(new FileReader(vol_filename));
	  boolean eof = false;
	  
      while (!eof) {
	    line = f.readLine().trim();
	    z++;
		
	    if (line.length()<1) continue; // empty line
		
		c = line.charAt(0);
		if (c==';' || c=='M' || c =='{') continue; // comment, MAPDIMXY, MAPTABPOLYS, {
		if (c=='}') { // end symbol reached
		  eof = true;
		  continue;
		}
		
		if (c!='P') {
		  System.out.println("\nInput Mismatch: Token 'POLY' expected!\nLine "+z+": "+line);
		  f.close();
		  System.exit(1);
		}
		
		c = line.charAt(4);
		int type = 0; // Poly type
		int num = 0;  // number of the POLY's extra paramters 
		
		switch (c) {
		  case ' ': { // POLY
		    break;
		  }
		  case 'R': { // POLYRAMPA
		    type = 1;
			num  = 1; // extra paramter = AlturaOff
		    break;
		  }
		  case 'Z': { // POLYZOOM
		    type = 2;
			num  = 1; // extra parameter = Zoom
		    break;
		  }
		  default: {
		    System.out.println("\nInput Mismatch: Unknown Token!\nLine "+z+": "+line);
		    f.close();
		    System.exit(1);
		  }
		}
		
		boolean isExplosion = false;
		StringTokenizer st = new StringTokenizer(line," ,\t"); // Seperators: Space, Comma, Tabulator
		st.nextToken(); // POLY/POLYRAMPA/POLYZOOM
		String nombre = st.nextToken(); // "NAME"
		if (nombre.substring(nombre.length()-4,nombre.length()-1).equals("EXP") || 
		    nombre.substring(nombre.length()-5,nombre.length()-2).equals("EXP")) {
		  isExplosion = true;
		}
		
		int values[] = new int[6+num]; // values = CentroX, CentroY, CentroZ, Altura, #vertices, #Tiles (plus extra paramters if Rampa or Zoom)
		for (int i=0;i<6+num;i++) {
		  values[i] = Integer.parseInt(st.nextToken());
		}
		
		int points_x[] = {};
		int points_y[] = {};
		
		// read points (or radio)
		if (values[4+num]==0) { // RADIO
		  line = f.readLine().trim();
		  z++;
		  while (line.length()==0) {
		    line = f.readLine().trim();
			z++;
		  }
		  
		  if (line.charAt(0)!='R') {
		    System.out.println("\nInput Mismatch: Token 'RADIO' expected!\nLine "+z+": "+line);
		    f.close();
		    System.exit(1);
		  }
		  
		  Scanner sc = new Scanner (line.substring(5,line.length()));
		  int radio = sc.nextInt();
		  
		  // create points
		  // NEW: 31-Jan-2011
		  points_x = new int[1];
		  points_y = new int[1];
		  points_x[0] = radio;
		  points_y[0] = values[3];

		} else { // POINTS
		  points_x = new int[values[4+num]];
		  points_y = new int[values[4+num]];
		  
		  for (int i=0;i<values[4+num];i++) {
			line = f.readLine().trim();
			z++;
			while (line.length()==0) {
		      line = f.readLine().trim();
			  z++;
		    }
			
			if (line.charAt(2)!='I') {
		      System.out.println("\nInput Mismatch: Token 'POINT' expected!\nLine "+z+": "+line);
		      f.close();
		      System.exit(1);
		    }
			
			StringTokenizer st2 = new StringTokenizer(line.substring(5,line.length()),",;");
			Scanner sc = new Scanner(st2.nextToken());
		    points_x[i] = sc.nextInt();
			sc = new Scanner(st2.nextToken());
		    points_y[i] = sc.nextInt()*-1;
		  }
		}
		
		line = f.readLine().trim(); // skip EXTRAINFO
		z++;
		while (line.length()==0) {
		  line = f.readLine().trim();
		  z++;
		}
		
		if (line.charAt(1)!='X') {
		  System.out.println("\nInput Mismatch: Token 'EXTRAINFO' expected!\nLine "+z+": "+line);
		  f.close();
		  System.exit(1);
		}
		
		// read tiles
		boolean valid = false;
		for (int i=0;i<values[5+num];i++) {
		  line = f.readLine().trim();
		  z++;
		  while (line.length()==0) {
		    line = f.readLine().trim();
			z++;
		  }
		  
		  if (line.charAt(0)!='T') {
		    System.out.println("\nInput Mismatch: Token 'TILE' expected!\nLine "+z+": "+line);
		    f.close();
		    System.exit(1);
		  }
		  StringTokenizer st2;
		  if (line.charAt(4)=='I') { // TILEID, used in some BCD files
		    st2 = new StringTokenizer(line.substring(7,line.length()),",");
		  } else { // TILE
		    st2 = new StringTokenizer(line.substring(5,line.length()),",");
		  }
		  Scanner sc;
		  int tile_values[] = new int[7]; // tile_values = x, y, width, height, hor. offset, vert. offset, brightness
		  for (int j=0;j<7;j++) {
 		    sc = new Scanner(st2.nextToken());
		    tile_values[j] = sc.nextInt();
		  }
		  String tilename = st2.nextToken();
		  tilename = tilename.substring(1,tilename.length()-1);
		  String transformations = st2.nextToken();
		  
		  if (tilename.length()<5) {
		    System.out.println("\nInvalid filename: '"+tilename+"'\nLine "+z+": "+line);
		    f.close();
		    System.exit(1);
		  }
		  if (tilename.charAt(tilename.length()-3)=='R' && tilename.charAt(0)!='-') { // check if RLE and not hidden
			
			// create image

			// create easy-to-read variables
			int width  = (int)(tile_values[2] * scale);
			int height = (int)(tile_values[3] * scale);
			int off_x  = (int)(tile_values[4] * scale);
			int off_y  = (int)(tile_values[5] * scale);
			boolean mirror = false;
			boolean flip   = false;
			if (transformations.charAt(1)=='X') mirror = true;
			if (transformations.charAt(2)=='Y') flip   = true;
			
			// get RLE from WAD
			boolean found = false;
			int j = 0;
			while (!found && j<nbrOfPictures) {
			  if (wad_isRle[j]) {
			    String this_name = rles[j].getName();
				if (tilename.equals(this_name)) {
				  found = true; // index of wad_rle is (j-1)
				}
			  }
			  j++;
			}
			
			if (!found || isExplosion) {
			  //System.out.println("\n\nError: Picture "+tilename+" not found in WAD!");
			  //System.out.println("\n"+z+": "+line+"\n");
			} else {
			
			valid = true;
			
			int rle_width  = rles[j-1].getWidth();
			int rle_height = rles[j-1].getHeight();
			int rle[][]    = rles[j-1].getData();
			
			// avoid negative offsets
			while (off_x<0) off_x+=rle_width;
			while (off_y<0) off_y+=rle_height;
			
			// avoid ArrayOutOfBoundsException
			if (width>rle_width)         width  = rle_width;
			if (height>rle_height)       height = rle_height;
			if (width+off_x>rle_width)   off_x  = rle_width-width;
			if (height+off_y>rle_height) off_y  = rle_height-height;
			
			// needed for MS bitmaps
			int spaces = (4 - (width % 4)) % 4;
			
			int sprite[][] = new int[height][width+spaces];
			
			// fill lines with 0's
			for (j=0;j<spaces;j++) {
			  for (int k=0;k<height;k++) {
			    sprite[k][width+j]=0;
			  }
			}
			
			if (!mirror && !flip) {
			  for (int y=0;y<height;y++) {
			    for (int x=0;x<width;x++) {
				  sprite[y][x] = rle[y+off_y][x+off_x];
				}
			  }
			} else if (mirror && !flip) {
			  for (int y=0;y<height;y++) {
			    for (int x=0;x<width;x++) {
				  sprite[y][x] = rle[y+off_y][rle_width-1-x-off_x];
				}
			  }
			} else if (!mirror && flip) {
			  for (int y=0;y<height;y++) {
			    for (int x=0;x<width;x++) {
				  sprite[y][x] = rle[rle_height-1-y-off_y][x+off_x];
				}
			  }
			} else { // (mirror && flip)
			  for (int y=0;y<height;y++) {
			    for (int x=0;x<width;x++) {
				  sprite[y][x] = rle[rle_height-1-y-off_y][rle_width-1-x-off_x];
				}
			  }
			}
			
			// create bmp in created directory (name = absolute path -> 'dir+"\\"+filename' won't work)
			FileOutputStream fos = new FileOutputStream(new File(dir.getAbsolutePath()+"\\"+tile_counter+".bmp"));
			
			// bmp header
			byte bmp[] = {66,77,127,0,0,0,0,0,0,0,54,4,0,0,40,0,0,0,127,0,0,0,127,0,0,0,1,0,8,0,0,0,0,0,127,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
		    int s0,s1,s2;
		    s0 = 1078 + height*(spaces+width);	// = Bitmap size (int)
		    s2 = 0;
            if (s0>65535) {
		      s2 = (int)java.lang.Math.floor((double)s0/65535);
		      s0-=s2*65535;
		    }
		    s1 = (int)java.lang.Math.floor((double)s0/256);
		    s0-=s1*256;
		  
            bmp[2] = (byte)s0;	// = Bitmap size (hex)
		    bmp[3] = (byte)s1;
		    bmp[4] = (byte)s2;
		
		    bmp[18] = (byte) (width % 256);    // width
		    bmp[19] = (byte)java.lang.Math.floor(width/256);
		
		    bmp[22] = (byte) (height % 256);    // heigth
		    bmp[23] = (byte)java.lang.Math.floor(height/256);
		
		    s0 = height*(spaces+width);	// = Bitmap size (int) without header
		    s2 = 0;
            if (s0>65535) {
		      s2 = (int)java.lang.Math.floor((double)s0/65535);
		      s0-=s2*65535;
		    }
		    s1 = (int)java.lang.Math.floor((double)s0/256);
		    s0-=s1*256;
		
		    bmp[34] = (byte)s0;	// = Bitmap size (hex) without header
		    bmp[35] = (byte)s1;
		    bmp[36] = (byte)s2;
		  
		    fos.write(bmp);
			
			// bmp color palette
			byte pal0[] = {0,0,0,0};
			byte pal1[] = {127,127,127,0};
			byte pal2[] = {-1,-1,-1,0};
			for (j=0;j<127;j++) fos.write(pal0);
			fos.write(pal1);
			for (j=0;j<128;j++) fos.write(pal2);
			
			// bmp pixel data
			for (int y=0;y<height;y++) {
			  for (int x=0;x<width+spaces;x++) {
			    fos.write(sprite[height-y-1][x]);
			  }
			}
			fos.flush();
			fos.close();
			// bmp created!

            // write render info			 
			fos2.write("      <RenderInfoBlockSerializationData>\n");
			fos2.write("        <ObjectIndex>"+counter+"</ObjectIndex>\n");
			fos2.write("        <x>"+(int)(tile_values[0]*scale)+"</x>\n");
			fos2.write("        <y>"+(int)(tile_values[1]*scale)+"</y>\n");
			fos2.write("        <RenderMapPath>"+tile_counter+".bmp</RenderMapPath>\n");
			fos2.write("      </RenderInfoBlockSerializationData>\n");
			  
			tile_counter++;
		  }
		  
		  } // if (!found) else
		}
		
		if (valid) {
		  // write object info
          fos1.write("    <ObjectInfoBlock>\n");
          fos1.write("      <Type>0</Type>\n");
          fos1.write("      <n>"+values[4+num]+"</n>\n");
          fos1.write("      <CenterX>"+(int)(values[0]*scale)+"</CenterX>\n");
		  if (angle==40) {
		    fos1.write("      <CenterY>"+(int)(values[1]*-1*scale)+"</CenterY>\n");
		  } else {
		    fos1.write("      <CenterY>"+(int)(values[1]*-1*scale * Math.sin((double)40 / 180 * Math.PI) / Math.sin((double)angle / 180 * Math.PI)) +"</CenterY>\n");
		  }
		  fos1.write("      <CenterZ>"+(int)(values[2]*scale)+"</CenterZ>\n");
          fos1.write("      <nx>0</nx>\n");
          fos1.write("      <ny>0</ny>\n");
		  
		  if (values[4+num] != 0) {
		    fos1.write("      <nz>1</nz>\n");
            if (type==2) {
              fos1.write("      <D>-"+(int)(values[4]*scale)+"</D>\n");
            } else {
              fos1.write("      <D>-"+(int)(values[3]*scale)+"</D>\n");
            }
            fos1.write("      <X>\n");
            for (int k=0;k<values[4+num];k++) {
              fos1.write("        <Single>"+(int)(points_x[values[4+num]-k-1]*scale)+"</Single>\n");
            }
            fos1.write("      </X>\n");
            fos1.write("      <Y>\n");
            for (int k=0;k<values[4+num];k++) {
              fos1.write("        <Single>"+(int)(points_y[values[4+num]-k-1]*scale)+"</Single>\n");
            }
            fos1.write("      </Y>\n");
		  } else { // RADIO
		    fos1.write("      <nz>0</nz>\n");
		    fos1.write("      <D>0</D>\n");
			fos1.write("      <X>\n");
			fos1.write("        <Single>"+(int)(points_x[0]*scale)+"</Single>\n");
			fos1.write("      </X>\n");
            fos1.write("      <Y>\n");
			fos1.write("        <Single>"+(int)(points_y[0]*scale)+"</Single>\n");
			fos1.write("      </Y>\n");
		  }
		  
          fos1.write("    </ObjectInfoBlock>\n");
          
          counter++; // increase counter if at least one valid tile found
		}
		
      }
      f.close();
	  
	  fos1.write("  </ObjectInfo>\n");
	  fos1.write("  <WaterMaskInfo>\n");
	  fos1.write("    <WaterMaskInfoBlockSerializationData />\n");
	  fos1.write("  </WaterMaskInfo>\n");
	  fos1.write("  <WaterMaskHighQualityInfo>\n");
	  fos1.write("    <WaterMaskInfoBlockSerializationData />\n");
	  fos1.write("  </WaterMaskHighQualityInfo>\n");
	  
	  fos2.write("    </ArrayOfRenderInfoBlock>\n");
	  fos2.write("  </RenderInfo>\n");
	  fos2.write("</MA2>");

	  fos1.flush();
	  fos1.close();
	  fos2.flush();
	  fos2.close();
	  
	  // read temp files and create Description.xml
	  System.out.print("done!\nCreating Description.xml...");
	  
	  FileOutputStream fos = new FileOutputStream(new File(dir.getAbsolutePath()+"\\Description.xml"));
	  
	  fos.write(0xFF);
	  fos.write(0xFE);
	  
	  byte next[] = {13,0,10,0};
	  
	  f = new BufferedReader(new FileReader(vol_filename+"_ObjectInfo.tmp"));
      while ((line = f.readLine()) != null) {
        for (int j=0;j<line.length();j++) {
		  fos.write(line.charAt(j));
	      fos.write(0);
		}
		fos.write(next);
      }
      f.close();

	  f = new BufferedReader(new FileReader(vol_filename+"_RenderInfo.tmp"));
      while ((line = f.readLine()) != null) {
        for (int j=0;j<line.length();j++) {
		  fos.write(line.charAt(j));
		  fos.write(0);
		}
		fos.write(next);
      }
      f.close();
	  
	  fos.flush();
	  fos.close();
	  
	  // delete temp files
	  File fil;
	  if (fos1_created) {
        fil = new File(vol_filename+"_ObjectInfo.tmp");
	    fil.delete();
      }
	  if (fos2_created) {
	    fil = new File(vol_filename+"_RenderInfo.tmp");
	    fil.delete();
	  }

	  System.out.println("done!");
	  
    } catch (IOException e) {
	  System.out.println("\n\n"+z+": "+line+"\n");
      e.printStackTrace();
    } catch (InputMismatchException e) {
	  System.out.println("\n\n"+z+": "+line+"\n");
	  e.printStackTrace();
	} catch (ArrayIndexOutOfBoundsException e) {
	  System.out.println("\n\n"+z+": "+line+"\n");
	  e.printStackTrace();
	} catch (StringIndexOutOfBoundsException e) {
	  System.out.println("\n\n"+z+": "+line+"\n");
	  e.printStackTrace();
	}
  }
}