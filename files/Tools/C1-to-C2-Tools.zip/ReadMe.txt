These tools can be used to convert map files from Commandos:BEL to Commandos 2
A Java Runtime Environment (JRE) is required to execute the .class files

MA2.java:
    INPUT:   BEL VOL + WAD
    OUTPUT:  MA2 Descripition File + Sprites (use CommDevToolkit's XmlConverter to create a MA2 file)
    USAGE:   java MA2 <file.VOL> <file.WAD> [angle scale]
			angle: int   (default: 40)
			scale: float (default: 1.0)

SEC5.java:
    INPUT:   BEL *.SEC file
    OUTPUT:  C2 *.SEC file
    USAGE:   java SEC5 <file.SEC> [scale isSnow [offset_x offset_y]]
			scale:    float (default: 1.0)
			isSnow:   int   (default: 1, 0=false, 1=true)
			offset_x: int   (default: 0)
			offset_y: int   (default: 0)

---
herbert3000
ferdinand.graf.zeppelin@gmail.com
sites.google.com/site/commandosmod/